package com.fang.usertrack.util;

import android.content.Context;
import android.content.res.AssetManager;
import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.alibaba.fastjson.parser.Feature;
import com.alibaba.fastjson.serializer.SerializerFeature;


import java.io.FileInputStream;
import java.io.InputStream;
import java.lang.reflect.Type;
import java.util.List;

/**
 * JsonObjUtil
 * Created by Liwei
 *
 */
public class JsonObjUtil {

    /**
     * parseObject
     *
     * @param jsonStr
     * @param entityClass
     * @param <T>
     * @return
     */
    public static <T> T parseObject(String jsonStr, Class<T> entityClass) {
        T ret = null;

        try {
            ret = JSON.parseObject(jsonStr, entityClass);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return ret;
    }

    public static <T> T parseObject(String jsonStr, Type type) {
        T obj = null;
        try {
            obj = JSON.parseObject(jsonStr, type, Feature.AutoCloseSource);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return obj;
    }


    public static <T> T parseObject(String jsonStr, TypeReference<T> tf) {
        T obj = null;
        try {
            obj = JSON.parseObject(jsonStr, tf, Feature.AutoCloseSource);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return obj;
    }

    /**
     * parseList
     *
     * @param jsonStr
     * @param entityClass
     * @param <T>
     * @return
     */
    public static <T> List<T> parseList(String jsonStr, Class<T> entityClass) {
        List<T> ret = null;

        try {
            ret = JSON.parseArray(jsonStr, entityClass);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return ret;
    }

    public static String toJSONString(Object obj) {
        String ret = null;

        try {
            ret = JSON.toJSONString(obj, SerializerFeature.DisableCheckSpecialChar,SerializerFeature.DisableCircularReferenceDetect);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return ret;
    }
    /**
     * 读文件操作
     *
     * @param fileName 文件名
     * @throws Exception
     */
    public static String  readFile(Context context, String fileName, boolean asset) {
        InputStream in;
        String str = null;
        AssetManager assetManager = context.getAssets();

        try {
            if (fileName!=null&&fileName.length()!=0) {
                if (asset) {
                    in = assetManager.open(fileName);
                } else {
                    in = new FileInputStream(fileName);
                }
                int size = in.available();
                byte[] buffer = new byte[size];
                in.read(buffer);
                in.close();
                str = new String(buffer, "utf-8");
            }
        } catch (Exception e) {
            Log.d("FUTAnalytics", e.getMessage());
        }
        return str;
    }
}
