package com.fang.usertrack;

/**
 * Created by user on 2017/12/6.
 */

public interface FUTAnalyticeInterface {
    public  String getPageName();
}
