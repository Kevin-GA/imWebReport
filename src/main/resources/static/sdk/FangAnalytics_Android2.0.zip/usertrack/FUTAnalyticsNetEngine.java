package com.fang.usertrack;


import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.fang.usertrack.db.helper.DataConstruct;
import com.fang.usertrack.db.helper.StaticsAgent;
import com.fang.usertrack.model.Result;
import com.fang.usertrack.util.JsonObjUtil;
import com.soufun.app.net.Apn;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import static com.soufun.app.net.NetConstants.ENCODING;

/**
 * Created by liwei on 2017-11-11.
 */
public class FUTAnalyticsNetEngine {


    /** instance */
    private static FUTAnalyticsNetEngine sInstance;

    /**
     * @return instance
     */
    public static synchronized FUTAnalyticsNetEngine getInstance() {
        if (sInstance == null) {
            sInstance = new FUTAnalyticsNetEngine();
        }
        return sInstance;
    }

    public void postHistoryJson(String url, final String keyName, HashMap<String, String> requestHead, final Context context, final String json, final String filepath ) {
        if (FUTAnalyticsConfig.DEBUG) {
            Log.i("FUTAnalytics", "postHistoryJson: " + json);
        }
        if (json==null||json.length()==0){
            return;
        }
        //申明给服务端传一个json
        //创建一个OkHttpClient对象
        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS)
                .readTimeout(10, TimeUnit.SECONDS)
                .build();
//        MediaType JSON=MediaType.parse("application/json; charset=utf-8");

        RequestBody formBody = new FormBody.Builder()
                .add(keyName, json)
                .build();
        //创建一个请求对象
        Request.Builder requestPostBuilder = new Request.Builder();
        for (Map.Entry<String, String> entry : requestHead.entrySet()) {
            String value = entry.getValue();
            if (value != null) {
                try {
                    value = URLEncoder.encode(value, "UTF-8");
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
                requestPostBuilder.addHeader(entry.getKey(), value);
            }
        }
        Request requestPost=requestPostBuilder.url(url)
                .post(formBody)
                .build();
        client.newCall(requestPost).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

                StaticsAgent.checkHistoryLog(context, filepath);

            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String string = response.body().string();
                Result result = JsonObjUtil.parseObject(string, Result.class);
                String str = null;
                if (result != null) {
                    str = result.getResult();
                }
                if (str != null && str.equals("1")) {
                    if (FUTAnalyticsConfig.DEBUG) {
                        Log.i("FUTAnalytics", "onResponse: " + "上传历史日志成功删除本地日志");
                    }
                    StaticsAgent.deleteHistoryLog(context, filepath);
                } else {
                    StaticsAgent.checkHistoryLog(context, filepath);

                }
            }

        });


    }

//    public void postJson(StaticsAgent agent ,HashMap<String,String> requestHead, final Context context, final String json,final String currLog) {
//        Log.i("FUTAnalytics", "postJson: ["+json+"]");
//
//        //申明给服务端传�?�一个json�?
//        //创建�?个OkHttpClient对象
//        OkHttpClient client = new OkHttpClient.Builder()
//                .connectTimeout(10, TimeUnit.SECONDS)
//                .readTimeout(10, TimeUnit.SECONDS)
//                .build();
//        //创建�?个RequestBody(参数1：数据类�? 参数2传�?�的json�?)
//        MediaType JSON=MediaType.parse("application/json; charset=utf-8");
//
//        RequestBody formBody = new FormBody.Builder()
//                .add("ut_loginfo", json)
//                .build();
//        //创建�?个请求对�?
//        Request.Builder requestPostBuilder = new Request.Builder();
//        for (Map.Entry<String, String> entry :requestHead.entrySet()) {
//            String value = entry.getValue();
//            if (value != null) {
//                try {
//                    value = URLEncoder.encode(value, "UTF-8");
//                } catch (UnsupportedEncodingException e) {
//                    e.printStackTrace();
//                }
//                requestPostBuilder.addHeader(entry.getKey(), value);
//            }
//        }
//
//        Request requestPost=requestPostBuilder.url(FUTAnalyticsConfig.ONLINE_URL)
//                .post(formBody)
//                .build();
//        //发�?�请求获取响�?
//
//        client.newCall(requestPost).enqueue(new Callback() {
//            @Override
//            public void onFailure(Call call, IOException e) {
//                if (FUTAnalyticsConfig.DEBUG){
//
//                    Log.i("FUTAnalytics", "onResponse: "+"上传日志失败网络错，保存日志");
//
//                }
//                DataConstruct.saveData(context,currLog);
//            }
//
//            @Override
//            public void onResponse(Call call, Response response) throws IOException {
//                final String string = response.body().string();
//                Result result = JsonObjUtil.parseObject(string,Result.class);
//
//                String str = null;
//                if(result!=null){
//                    str = result.getResult();
//                }
//                if (str!=null&&str.equals("1")){
//
//                    if (agent!=null) {
//                        DataConstruct.deteleData(agent);
//                    }
//                    StaticsAgent.deleteHistoryLog(context);
//
//                    if (FUTAnalyticsConfig.DEBUG){
//
//                        Log.i("FUTAnalytics", "onResponse: "+"上传日志成功,删除历史");
//                    }
//
//                }  else{
//                    if (FUTAnalyticsConfig.DEBUG){
//
//                        Log.i("FUTAnalytics", "onResponse: "+"上传日志失败，保存日�?");
//
//                    }
//                }
//
//            }
//
//        });
//
//
//    }
}