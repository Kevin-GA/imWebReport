package com.fang.usertrack;

import com.fang.usertrack.model.HeadModel;

import java.util.HashMap;

/**
 * Created by liwei on 2017-11-12.
 */
public interface FUTAnalyticsInterfaceListener {
 /**
  *使用者实现获取head的方法请求需要的
  */
 HashMap<String, String> getHeadMaps();

 /**
  *
  * @return 生成每条日志需要的
  */
 HeadModel getHeadModel();

 String getNetWorkType();
 String getServiceUrl();

 /**
  * 获取当前选择的城市
  * @return
  */
 String getCity();

 /**
  * 获取当前x坐标
  * @return
  */
 String getX();

 /**
  * 获取当前Y坐标
  * @return
  */
 String getY();
}
