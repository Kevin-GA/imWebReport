package com.fang.usertrack.db.helper;

import android.content.Context;
import android.os.Environment;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;


import com.fang.usertrack.FUTAnalyticsConfig;

import com.fang.usertrack.model.AppAction;
import com.fang.usertrack.model.AppActionList;
import com.fang.usertrack.model.DataBlock;
import com.fang.usertrack.model.Event;
import com.fang.usertrack.model.EventList;
import com.fang.usertrack.model.Page;
import com.fang.usertrack.model.PageList;
import com.soufun.app.SoufunConstants;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.UUID;
/**
 * Created by liwei on 2017-11-17. 将数据缓存在内存了，后期可以考虑文件或数据库
 */
public class StaticsAgent {

    private  PageList pageList;
    private  EventList eventList;
    private  AppActionList appActionList;
    private  String session_id;
    private  String session_startTime;
    private  String session_endTime;
//    private static String UTAnalytics_logs = "/UTAnalytics_logs";
    private  int totalCount;
//    private static Long startTime;
    /**
     * @param context
     */
    public  void init(Context context,String sessionID,String start_Time) {
        session_id = sessionID;
        appActionList = new AppActionList();
        pageList = new PageList();
        eventList = new EventList();
        totalCount = 0;
        session_startTime = start_Time;

    }

    /**
     * 存储appAction相关信息
     *
     * @param appAction
     */
    public  void storeAppAction(AppAction appAction) {
          session_endTime = appAction.getAction_time();
    }

    /**
     * storePage
     *
     * @param page
     */
    public  void storePage(Page page) {
        if (pageList == null) {
            pageList = new PageList();
        }
        pageList.getList().add(page);
        totalCount++;


    }

    /**
     * storeEvent
     *
     * @param envent
     */
    public  void storeEvent(Event envent) {
        if (eventList == null) {
            eventList = new EventList();
        }
        eventList.getList().add(envent);
        totalCount++;

    }

    public  DataBlock getDataBlock() {
        if (pageList == null && eventList == null) {
            return null;
        }
        if (pageList.getList().size() == 0 && eventList.getList().size() == 0) {
            return null;

        }
        DataBlock dataBlock = new DataBlock();
        dataBlock.setSession_id(session_id);
        dataBlock.setStart_time(session_startTime);
        dataBlock.setEnd_time(session_endTime);

        if (session_startTime != null && session_endTime != null) {
            Long durationTime = Long.valueOf(session_endTime) - Long.valueOf(session_startTime);
            dataBlock.setDuration(String.valueOf(durationTime));
        }
        if (pageList.getList().size()>0) {
            dataBlock.setPages(pageList.getList());
        }

        if (eventList.getList().size()>0) {
            dataBlock.setEvents(eventList.getList());
        }
        return dataBlock;
    }


    /**
     * storeObject
     *
     * @param o
     */
    public  int storeObject(Object o) {


        if (o instanceof Event) {
            storeEvent((Event) o);
        } else if (o instanceof AppAction) {
            storeAppAction((AppAction) o);
        } else if (o instanceof Page) {
            storePage((Page) o);
        }

//        Long duration = System.currentTimeMillis()-startTime;
//        if (duration>=FUTAnalyticsConfig.intervalTime){
//
//            return Boolean.TRUE ;
//        }
        if (FUTAnalyticsConfig.DEBUG){
            Log.i("FUTAnalytics", totalCount+":"+o.toString());
        }
        return totalCount;
    }

    public  void deleteDatas() {
        appActionList = null;
        pageList = null;
        eventList = null;
        totalCount = 0;

    }

    //判断文件是否存在
    public static boolean fileIsExists(String strFile) {
        try {
            File f = new File(strFile);
            if (!f.exists()) {
                return false;
            }

        } catch (Exception e) {
            return false;
        }

        return true;
    }

    public static void saveLogFile(Context context, String log) {

        // todo 保存文件
        String logs = log;
       String filePath = context.getFilesDir() + FUTAnalyticsConfig.UTAnalytics_logs;
        if (fileIsExists(filePath)) {
            logs = "," + log;
        }
        FileOutputStream outputStream = null;

        try {
            File file = new File(filePath);
//            outputStream = context.openFileOutput(file, Context.MODE_APPEND);
            outputStream = new FileOutputStream(file,true);
            outputStream.write(logs.getBytes());
            outputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (outputStream != null) {
                try {
                    outputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    public static void checkHistoryLog(Context context, String path) {
        String filePath = context.getFilesDir() + path;
        File file = new File(filePath);
        if(file!=null&&file.exists()){

            long length = file.length();
            if (FUTAnalyticsConfig.DEBUG) {
                Log.i("FUTAnalyticsLogSize", "size: "+file.length());
            }
           if (length>=1024*400){
               file.delete();
               if (FUTAnalyticsConfig.DEBUG) {
                   Log.i("FUTAnalyticsLogSize", "文件大小大于1M删除本地日志");
               }
           }
        }

    }
    public static String getHistoryLog(Context context, String path) {

        FileInputStream in = null;
        BufferedReader reader = null;
        StringBuilder content = new StringBuilder();
        try {
            String filePath = context.getFilesDir() + path;
            File file = new File(filePath);

            in = new FileInputStream(file);
            reader = new BufferedReader(new InputStreamReader(in));
            String line = "";


            while ((line = reader.readLine()) != null) {
                content.append(line);
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return content.toString();

    }

    public static void deleteHistoryLog(Context context, String path) {


        String filePath = context.getFilesDir() + path;

        try {
            File f = new File(filePath);
            if (f.exists()) {
                f.delete();
            }

        } catch (Exception e) {

        }
    }

    public  void copyAgent(DataBlock dataBlock){

        session_id = dataBlock.getSession_id();
        session_startTime = dataBlock.getStart_time();


    }

    public static void saveCrashLogFile(Context context, String log) {

        String filePath = context.getFilesDir() + FUTAnalyticsConfig.CrashAnalytics_logs;
        if (fileIsExists(filePath)) {
            deleteHistoryLog(context, FUTAnalyticsConfig.CrashAnalytics_logs);
        }

        FileOutputStream outputStream = null;
        try {
            File file = new File(filePath);
            outputStream = new FileOutputStream(file,true);
            outputStream.write(log.getBytes());
            outputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (outputStream != null) {
                try {
                    outputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public static String getUidFromBase64(String base64Id){
        String result ="";
        if(!TextUtils.isEmpty(base64Id)){
            result = new String(Base64.encodeToString(base64Id.getBytes(),Base64.DEFAULT));
        }
        return result;
    }
}

