package com.fang.usertrack.db.helper;


import android.content.ContentProvider;
import android.content.Context;
import android.text.TextUtils;


import com.fang.usertrack.model.AppAction;
import com.fang.usertrack.model.Event;
import com.fang.usertrack.model.Page;


import java.util.HashMap;
import java.util.Map;

/**
 * DataConstruct
 * Created by liwei on 2017-11-17.
 */
public class DataConstruct {


    public static Event event = null;
    private static HashMap<String,String> parameter;

    public static Page page = null ;
    private static HashMap<String,String> pageParameter;

    private static AppAction appAction = null ;

    public static Event getEvent() {
        return event;
    }

    public static void setEvent(Event event) {
        DataConstruct.event = event;
    }

    public static Page getPage() {
        return page;
    }

    public static void setPage(Page page) {
        DataConstruct.page = page;
    }
    // 当前页面名称
    private static String currPageName;
    // 页面来源
    private static String referPageName;

    private static String REFERPAGE_ID = "referPage_Id";

    public   static String sessionID;

    public static String getSessionID() {
        return sessionID;
    }

    public static void setSessionID(String sessionID) {
        DataConstruct.sessionID = sessionID;
    }

    private DataConstruct() {

    }



    /**
     * initEvent
     * @param event_name
     */
    public static void initEvent(String event_name,String city ,String x,String y){

     initEvent(event_name,"click",city,x,y);

    }
    public static void initEvent(String event_name,String event_type,String city ,String x,String y){
        event = new Event();
        event.setPi(currPageName);
        event.setEventtype(event_type);
        event.setEventname(event_name);
        event.setCity(city);
        event.setX1(x);
        event.setY1(y);
        event.setTime(String.valueOf(System.currentTimeMillis()));
    }
//    public static void initEventWithPageName(String event_name,String _currPageName){
//        event = new Event();
//        event.setPi(_currPageName);
//        event.setEventtype("click");
//        event.setEventname(event_name);
//        event.setTime(String.valueOf(System.currentTimeMillis()));
//    }

    /**
     *  onEvent
     */
    public static void onEvent(Map<String,String> parameter){
         if(event == null){
            throw new RuntimeException("you must call initEvent before onEvent!");
        }
        if (parameter==null||parameter.size()==0){
            return;
        }
        HashMap map = new HashMap();

        for(String key :parameter.keySet()){
            String value = parameter.get(key);
            if (!DataConstruct.isNullOrEmpty(value)){

                String mkey = key.toLowerCase();
                String mvalue = value.toLowerCase();
                map.put(mkey,mvalue);
            }
        }
            event.setExt(map);
    }

    /**
     * storeEvent
     * Activity destory call
     */
    public static int storeEvent(StaticsAgent agent){
        if(event == null){
            return 0;
        }
       return agent.storeObject(event);
    }


    /**
     * initPage

     */
    public static void initPage(Context context, String page_name, String referPage_name,String refer_referPage_name,String city ,String x ,String y){
        currPageName = page_name;
//        recardPageId(context, page_name);
        if (!TextUtils.isEmpty(referPage_name)){
             referPageName = referPage_name;
        }
        page = new Page();
        page.setSt(String.valueOf(System.currentTimeMillis()));
        page.setS(referPage_name);
        page.setPi(page_name);
        page.setSs(refer_referPage_name);
        page.setCity(city);
        page.setX1(x);
        page.setY1(y);

    }


    public static void initPageParameter(Map<String,String> pageParameter){
        if (pageParameter==null||pageParameter.size()==0){
            return;
        }
        HashMap map = new HashMap();
        for(String key :pageParameter.keySet()){
            String value = pageParameter.get(key);
            if (!DataConstruct.isNullOrEmpty(value)){

                String mkey = key.toLowerCase();
                String mvalue = value.toLowerCase();
                map.put(mkey,mvalue);

            }
        }
        page.setExt(map);
    }


    /**
     * storePage
     */
    public static int storePage(StaticsAgent agent){
        if(page == null){
            throw new RuntimeException("you must init before storePage");
        }
        Long et = System.currentTimeMillis();
        page.setEt(String.valueOf(et));
        String st = page.getSt();
        Long durationTime =  et-Long.valueOf(st);
       //  设置停留时间
        page.setSet(String.valueOf(durationTime));
        // 本地保存
       return agent.storeObject(page);
    }


    /**
     * storeAppAction
     * @param  1 app打开  2app关闭  3唤醒
     */
    public static void storeAppAction(StaticsAgent agent){
        appAction = new AppAction();
        String actionTime = String.valueOf(System.currentTimeMillis());
        appAction.setAction_time(actionTime);

        agent.storeAppAction(appAction);

    }




    /**
     * saveData
     */
    public static void saveData(Context context,String log){
        StaticsAgent.saveLogFile(context,log);
    }
    /**
     * deteleData
     */
    public static void deteleData(StaticsAgent agent){
        agent.deleteDatas();
    }

    public static boolean isNullOrEmpty(String text) {
        if (text == null || "".equals(text.trim()) || text.trim().length() == 0
                || "null".equals(text.trim())) {
            return true;
        } else {
            return false;
        }
    }
}