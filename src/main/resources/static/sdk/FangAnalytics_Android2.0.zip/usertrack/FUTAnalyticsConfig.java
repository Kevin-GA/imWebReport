package com.fang.usertrack;

import android.os.Environment;

/**
 * Created by liwei on 2017/11/17.
 */

public class FUTAnalyticsConfig {
    public static boolean DEBUG = false;    /** 是否是debug版本 */
    public static String SDKVERSION = "2.0.0";//sdk 版本号
    public static String ONLINE_URL;
    public static int limitCountForWifi = 30;
    public static int limitCountFor4G = 50;
    public static String REFERPAGENAME = "referPageName";
    public static String BEFOREREFERPAGENAME = "referrePageName";
    public static String SDKUT = "ut_loginfo";
    public static String SDKCRASH = "crash_loginfo";
    public static String UTAnalytics_logs = "/UTAnalytics_logs";
    public static String CrashAnalytics_logs = "/CrashAnalytics_logs";


    public static long intervalTime = (long) 1 * 60 * 1000;
}
