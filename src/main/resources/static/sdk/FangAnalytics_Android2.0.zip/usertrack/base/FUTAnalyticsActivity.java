package com.fang.usertrack.base;

import android.app.Activity;
import android.content.Intent;


import com.fang.usertrack.FUTAnalyticeInterface;
import com.fang.usertrack.FUTAnalytics;



/**
 * Created by user on 2017/12/6.
 */

public class FUTAnalyticsActivity extends Activity implements FUTAnalyticeInterface{



    @Override
    public void startActivity(Intent intent) {

       FUTAnalytics.startActivity(this,intent);
        super.startActivity(intent);
    }


    @Override
    public void startActivityForResult( Intent intent, int requestCode) {
        FUTAnalytics.startActivity(this,intent);

        super.startActivityForResult(intent, requestCode);
    }

    @Override
    public String getPageName() {
        return null;
    }
}
