package com.fang.usertrack.base;

import android.content.Intent;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;

import com.fang.usertrack.FUTAnalyticeInterface;
import com.fang.usertrack.FUTAnalytics;

/**
 * Created by user on 2017/12/6.
 */

public class FUTAnalyticsFragmentActivity extends FragmentActivity implements FUTAnalyticeInterface{


    @Override
    public void startActivity(Intent intent) {
        FUTAnalytics.startActivity(this,intent);
        super.startActivity(intent);
    }

    @Override
    public void startActivityFromFragment( Fragment fragment, Intent intent, int requestCode) {

        FUTAnalytics.startActivity(this,intent);
        super.startActivityFromFragment(fragment, intent, requestCode);
    }
    @Override
    public void startActivityForResult( Intent intent, int requestCode) {
        FUTAnalytics.startActivity(this,intent);

        super.startActivityForResult(intent, requestCode);
    }
    @Override
    public String getPageName() {
        return null;
    }
}

