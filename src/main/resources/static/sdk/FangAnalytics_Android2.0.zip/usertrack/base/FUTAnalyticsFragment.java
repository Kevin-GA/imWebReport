package com.fang.usertrack.base;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;

import com.fang.usertrack.FUTAnalyticeInterface;
import com.fang.usertrack.FUTAnalytics;
import com.fang.usertrack.FUTAnalyticsConfig;
import com.soufun.app.BaseActivity;
import com.soufun.app.activity.base.BaseFragment;

/**
 * Created by user on 2017/12/6.
 */

public class FUTAnalyticsFragment extends Fragment implements FUTAnalyticeInterface,FragmentUserVisibleController.UserVisibleCallback{

    private FragmentUserVisibleController userVisibleController;

    public  String currPageName ;
    public  String referPageName ;
    public  String reReferPageName ;


    public FUTAnalyticsFragment() {
        userVisibleController = new FragmentUserVisibleController(this, this);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        userVisibleController.activityCreated();
    }


    @Override
    public void onResume() {
        super.onResume();
//        Log.i("FUTAnalytics", this.getClass().getSimpleName() + " onResume");
//
//
//        if (getUserVisibleHint()) {
//            onVisibilityChangedToUser(true, false);
//        }

        userVisibleController.resume();

    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {

        super.setUserVisibleHint(isVisibleToUser);


//        if(isResumed()){
//            onVisibilityChangedToUser(isVisibleToUser, true);
//        }
        userVisibleController.setUserVisibleHint(isVisibleToUser);


    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);

    }

    @Override
    public void onPause() {
        super.onPause();

//        if(getUserVisibleHint()){
//            onVisibilityChangedToUser(false, false);
//        }
        userVisibleController.pause();

    }

    @Override
    public void startActivity(Intent intent) {
        Activity activity= getActivity();
        if (activity == null){
            return;
        }
        FUTAnalytics.startActivity(activity,intent);

        super.startActivity(intent);


    }
    @Override
    public void startActivityForResult( Intent intent, int requestCode) {
        Activity activity= getActivity();
        if (activity == null){
            return;
        }
        FUTAnalytics.startActivity(activity,intent);

        super.startActivityForResult(intent, requestCode);
    }
    public String getFUTPageName(){

        return FUTAnalytics.getPageNameForFrament(this);
    }

    @Override
    public String getPageName() {
        return null;
    }

    /**
     * 当Fragment对用户的可见性发生了改变的时候就会回调此方法
     * @param isVisibleToUser true：用户能看见当前Fragment；false：用户看不见当前Fragment
     * @param isHappenedInSetUserVisibleHintMethod true：本次回调发生在setUserVisibleHintMethod方法里；false：发生在onResume或onPause方法里
     */
    public void onVisibilityChangedToUser(boolean isVisibleToUser, boolean isHappenedInSetUserVisibleHintMethod){

        String  registerPageName = FUTAnalytics.getRegisterFUTPageName(this.getClass().getSimpleName());
//                if (FUTAnalyticsConfig.DEBUG){
//                    Log.i("FUTAnalytics", "onResume: "+currPageName+"|"+referPageName+"|"+reReferPageName);
//                }

        if (registerPageName.length()==0){
//                    if (FUTAnalyticsConfig.DEBUG){
//                        Log.i("FUTAnalytics", activity.getClass().getSimpleName()+"onActivityResumed: "+"未注册页面不统计");
//                    }
            return;
        }

        if(isVisibleToUser){
            Activity activity= getActivity();
            if (activity == null){
                return;
            }
            currPageName = getFUTPageName();
            if (currPageName==null){
                Log.i("FUTAnalytics", "需要重写 getPageName()");

            }
            referPageName =  activity.getIntent().getStringExtra(FUTAnalyticsConfig.REFERPAGENAME);
            reReferPageName = activity.getIntent().getStringExtra(FUTAnalyticsConfig.BEFOREREFERPAGENAME);


            FUTAnalytics.recordPageStart(activity,currPageName,referPageName,reReferPageName);


        }else{

            FUTAnalytics.recordPageEnd();


        }
    }

    @Override
    public void setWaitingShowToUser(boolean waitingShowToUser) {
        userVisibleController.setWaitingShowToUser(waitingShowToUser);
    }

    @Override
    public boolean isWaitingShowToUser() {
        return userVisibleController.isWaitingShowToUser();
    }

    @Override
    public boolean isVisibleToUser() {
        return userVisibleController.isVisibleToUser();
    }

    @Override
    public void callSuperSetUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
    }

    @Override
    public void onVisibleToUserChanged(boolean isVisibleToUser, boolean invokeInResumeOrPause) {
        String  registerPageName = FUTAnalytics.getRegisterFUTPageName(this.getClass().getSimpleName());
//                if (FUTAnalyticsConfig.DEBUG){
//                    Log.i("FUTAnalytics", "onResume: "+currPageName+"|"+referPageName+"|"+reReferPageName);
//                }

        if (registerPageName.length()==0){
//                    if (FUTAnalyticsConfig.DEBUG){
//                        Log.i("FUTAnalytics", activity.getClass().getSimpleName()+"onActivityResumed: "+"未注册页面不统计");
//                    }
            return;
        }

        if(isVisibleToUser){
            Activity activity= getActivity();
            if (activity == null){
                return;
            }
            currPageName = getFUTPageName();
            if (currPageName==null){
                Log.i("FUTAnalytics", "需要重写 getPageName()");

            }
            referPageName =  activity.getIntent().getStringExtra(FUTAnalyticsConfig.REFERPAGENAME);
            reReferPageName = activity.getIntent().getStringExtra(FUTAnalyticsConfig.BEFOREREFERPAGENAME);


            FUTAnalytics.recordPageStart(activity,currPageName,referPageName,reReferPageName);


        }else{

            FUTAnalytics.recordPageEnd();


        }
    }

}
