package com.fang.usertrack;

import android.content.Context;

import java.util.Map;

/**
 * Created by liuxiao on 2017/11/15.
 */

public interface FUTAnalyticsManager {
    boolean onInit(FUTAnalyticsInterfaceListener headListener);

    void onSend();

    void onStore();

    void onRelease();

    void onRecordAppStart();

    void onRrecordPageEnd();

    void onRecordPageStart(Context context, String currPageName, String referPageName, String referreferPageName);

    void onRecordPageStart(Context context);

    void onRrecordAppEnd();

    void onInitPage(String... strings);

//    void onPageParameter(String key,String value);

    void onPageParameters(Map<String, String> parameter);

    void onInitEvent(String eventName);

    void onInitEvent(String eventName,String eventType);


    void onEventParameters(Map<String, String> parameter);

    FUTAnalyticsInterfaceListener  getInterfaceListener();

    void xiaoMICaidan();

    void saveCrashInfoToFile(Throwable ex);
}