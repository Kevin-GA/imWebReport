package com.fang.usertrack.observer;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.util.Log;

import com.fang.usertrack.FUTAnalyticsConfig;
import com.fang.usertrack.FUTAnalyticsIntentManager;

/**
 * Created by liwei on 2017/11/17.
 */

public class FangDeblockObserver extends BroadcastReceiver {



    /**
     * DEBUG mode
     */
    private static final boolean DEBUG = FUTAnalyticsConfig.DEBUG;
    /**
     * Log TAG
     */
    private static final String Log_TAG = FangDeblockObserver.class.getSimpleName();
    /**
     * Context
     */
    private Context mContext;
    /**
     * IKeyguardListener
     */
    private IKeyguardListener mListener;

    /**
     * Constructor
     *
     * @param aContext  Context
     * @param aListener IScreenListener
     */
    public FangDeblockObserver(Context aContext, IKeyguardListener aListener) {
        mContext = aContext;
        mListener = aListener;
    }

    /**
     * start Listener
     */
    public void start() {
        try {
            IntentFilter filter = new IntentFilter();
            filter.addAction(Intent.ACTION_USER_PRESENT);
            mContext.registerReceiver(this, filter);

            if (!isScreenLocked(mContext)) {
                if (mListener != null) {
                    mListener.onKeyguardGone(mContext);
                }
            }
        } catch (Exception e) {
            if (DEBUG) {
                Log.w(Log_TAG, "start Exception", e);
            }
        }
    }

    /**
     * stop Listener
     */
    public void stop() {
        try {
            mContext.unregisterReceiver(this);
        } catch (Exception e) {
            if (DEBUG) {
                Log.w(Log_TAG, "stop Exception", e);
            }
        }
    }

    /**
     * is Screen Locked
     *
     * @param aContext Context
     * @return true if screen locked, false otherwise
     */
    public boolean isScreenLocked(Context aContext) {
        android.app.KeyguardManager km = (android.app.KeyguardManager) aContext
                .getSystemService(Context.KEYGUARD_SERVICE);
        return km.inKeyguardRestrictedInputMode();
    }

    @Override
    public void onReceive(Context aContext, Intent aIntent) {
        if (FUTAnalyticsIntentManager.getInstance().isUserPresentIntent(aIntent)) {
            if (mListener != null) {
                mListener.onKeyguardGone(aContext);
            }
        }
    }

    /**
     * IKeyguardListener
     */
    public interface IKeyguardListener {

        /**
         * unlock
         *
         * @param aContext Context
         */
        void onKeyguardGone(Context aContext);
    }
}
