package com.fang.usertrack;

import android.app.Activity;
import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.fang.usertrack.base.FUTAnalyticsActivity;
import com.fang.usertrack.db.helper.DataConstruct;
import com.fang.usertrack.model.AppAction;
import com.fang.usertrack.model.Page;
import com.fang.usertrack.model.PageInfo;
import com.fang.usertrack.util.JsonObjUtil;
import com.fang.usertrack.util.MIUIUtils;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by liwei on 2017/11/15.
 */

public final class FUTAnalytics {

    /**批量上报 达到一定次数*/
    protected static final int UPLOAD_POLICY_BATCH = 0;
    /**时间间隔*/
    protected static final int UPLOAD_POLICY_INTERVAL = 1;
    /**开发者debug模式 调用就可以发送*/
    protected static final int UPLOAD_POLICY_DEVELOPMENT = 2;
    /**每次退到后台 发送本次产生的数据*/
    protected static final int UPLOAD_POLICY_WHILE_BACKGROUND = 3;

   public static int mFinalCount;

   public static HashMap<String,PageInfo> pageInfoMap;
    /**
     * 上报策略模式
     */
    public enum UploadPolicy {

        /**批量上报 达到一定次数*/
        UPLOAD_POLICY_BATCH,
        /**时间间隔*/
        UPLOAD_POLICY_INTERVA,
        /**开发者debug模式 调用就可以发送*/
        UPLOAD_POLICY_DEVELOPMENT,
        /**每次退到后台 发送本次产生的数据*/
        UPLOAD_POLICY_WHILE_BACKGROUND
    }

    /**1分钟*/
    public static final int UPLOAD_TIME_ONE = 1;
    /**
     * 上报策略
     */
    protected static UploadPolicy uploadPolicy;

    private static int intervalRealtime = UPLOAD_TIME_ONE;

    private static Context context;


    private FUTAnalytics(){

    }
    public static void init() {
        //读取配置文件
        String configInfo = JsonObjUtil.readFile(context,"FUTAnalyticsConfig.json", true);
//        if (FUTAnalyticsConfig.DEBUG) {
//
//            Log.i("FUTAnalytics", "configInfo = " + configInfo);
//        }
        if (configInfo==null||configInfo.length()==0) {
            return;
        }

        //解析配置文件
        if (pageInfoMap == null) {
//            pageInfoMap = JsonObjUtil.parseObject(configInfo,pageInfoMap.getClass());
            pageInfoMap = new HashMap<>();
            List<PageInfo> pageList = JsonObjUtil.parseList(configInfo,PageInfo.class);

            for (PageInfo pageInfo :pageList){
              String pageType = pageInfo.getPageType();

                if (pageType!=null&&!pageType.equals("3")){

                    String pageClass = pageInfo.getPageClass();

                    pageInfoMap.put(pageClass, pageInfo);
                }

            }
         }


    }

    public static void initialize(final Context aContext, FUTAnalyticsInterfaceListener headListener) {
        context = aContext;

        init();



        FUTSDK.getInstance(aContext).init(headListener);

        ((Application)aContext).registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {

            @Override
            public void onActivityCreated(Activity activity, Bundle savedInstanceState) {

            }

            @Override
            public void onActivityStarted(Activity activity) {
                mFinalCount++;
                //如果mFinalCount ==1，说明是从后台到前台
                Log.e("onActivityStarted", mFinalCount +"");
                if (mFinalCount == 1){
                    //说明从后台回到了前台
                    FUTAnalytics.recordAppStart();
                }
            }

            @Override
            public void onActivityResumed(Activity activity) {
                if (activity==null){
                    return;
                }
                String currPageName = FUTAnalytics.getPageName(activity);
                String   referPageName = activity.getIntent().getStringExtra(FUTAnalyticsConfig.REFERPAGENAME);
                String   reReferPageName = activity.getIntent().getStringExtra(FUTAnalyticsConfig.BEFOREREFERPAGENAME);
                String  registerPageName = FUTAnalytics.getRegisterFUTPageName(activity.getClass().getSimpleName());
//                if (FUTAnalyticsConfig.DEBUG){
//                    Log.i("FUTAnalytics", "onResume: "+currPageName+"|"+referPageName+"|"+reReferPageName);
//                }

                if (registerPageName.length()==0){
//                    if (FUTAnalyticsConfig.DEBUG){
//                        Log.i("FUTAnalytics", activity.getClass().getSimpleName()+"onActivityResumed: "+"未注册页面不统计");
//                    }
                    return;
                }
                FUTAnalytics.recordPageStart(activity,currPageName,referPageName,reReferPageName);

            }

            @Override
            public void onActivityPaused(Activity activity) {

                if (activity == null){
                    return;
                }

                String registerPageName = FUTAnalytics.getRegisterFUTPageName(activity.getClass().getSimpleName());

                if (registerPageName.length()==0){
//                    if (FUTAnalyticsConfig.DEBUG){
//                        Log.i("FUTAnalytics", activity.getClass().getSimpleName()+"onActivityPaused: "+"未注册页面不统计");
//                    }
                    return;
                }
                FUTAnalytics.recordPageEnd();

            }

            @Override
            public void onActivityStopped(Activity activity) {
                mFinalCount--;
                //如果mFinalCount ==0，说明是前台到后台
                Log.i("onActivityStopped", mFinalCount +"");
                if (mFinalCount == 0){
                    //说明从前台回到了后台
                    FUTAnalytics.recordAppEnd();
                }
            }

            @Override
            public void onActivitySaveInstanceState(Activity activity, Bundle outState) {

            }

            @Override
            public void onActivityDestroyed(Activity activity) {

            }
        });

    }
    /**
     * 设置策略模式
     * @param policy
     *     策略模式（实时模式下间隔时间无效）
     *     目前默认为UPLOAD_POLICY_INTERVA模式
     * @param time
     *     时间间隔（1 5 10 20 30分钟）
     */
    public static void setUploadPolicy(UploadPolicy policy, int time) {

        if (policy == null) {
            uploadPolicy = UploadPolicy.UPLOAD_POLICY_INTERVA;
            return;
        }

        if (time > 0 || time <= 60) {
            intervalRealtime = time;
        }
        uploadPolicy = policy;

    }

    /**
     * getIntervalRealtime
     * @return  intervalRealtime
     */
    public static int getIntervalRealtime() {
        return intervalRealtime;
    }

    public static void setIntervalRealtime(int intervalRealtime) {
        FUTAnalytics.intervalRealtime = intervalRealtime;
    }

    /** setUrl
     * @param url
     */
    public static void setUrl(String url) {
        FUTAnalyticsConfig.ONLINE_URL = url;
    }

    /**
     * record Page Start
     * */
    public static void recordPageStart(Activity activity) {

        String   currPageName = FUTAnalytics.getPageName(activity);
        String   referPageName = activity.getIntent().getStringExtra(FUTAnalyticsConfig.REFERPAGENAME);
        String   reReferPageName = activity.getIntent().getStringExtra(FUTAnalyticsConfig.BEFOREREFERPAGENAME);

        FUTAnalytics.recordPageStart(activity,currPageName,referPageName,reReferPageName);

    }
    public  static void recordPageStart(Context mcontext,String currPageName,String referPageName,String referreferPageName){

//        if (FUTAnalyticsConfig.DEBUG){
//                    Log.i("FUTAnalytics", "recordPageStart: "+currPageName+"|"+referPageName+"|"+referreferPageName);
//                }
        FUTSDK.getInstance(context).recordPageStart(mcontext,currPageName,referPageName,referreferPageName);

    }

//    public  static void updatePageName(Context mcontext,String currPageName,String referPageName,String referreferPageName){
//
////        if (FUTAnalyticsConfig.DEBUG){
////                    Log.i("FUTAnalytics", "recordPageStart: "+currPageName+"|"+referPageName+"|"+referreferPageName);
////                }
//        FUTSDK.getInstance(context).recordPageStart(mcontext,currPageName,referPageName,referreferPageName);
//
//    }
    /**
     * record Page End
     */
    public static void recordPageEnd() {
         FUTSDK.getInstance(context).recordPageEnd();

    }

    /**
     * record App Start
     */
    public static void recordAppStart() {

        FUTSDK.getInstance(context).recordAppStart();


    }

    /**
     * 关闭APP
     */
    public static void recordAppEnd() {

        FUTSDK.getInstance(context).recordAppEnd();


        FUTSDK.getInstance(context).release();
    }

    /**
     * 上报数据
     * 非Debug模式无法直接调用，请先设置为UPLOAD_POLICY_DEVELOPMENT
     */
    protected static void report() {


        FUTSDK.getInstance(context).send();

    }

    /**
     * 上报数据
     * 非Debug模式无法直接调用，请先设置为UPLOAD_POLICY_DEVELOPMENT
     */
    public static void reportData() {


        if (uploadPolicy != UploadPolicy.UPLOAD_POLICY_DEVELOPMENT) {

            throw new RuntimeException("call reportData(), you must will UploadPolicy set : UPLOAD_POLICY_DEVELOPMENT!");
        }

        report();

    }


    /**
     * 加入page参数
     * @param pageParameters 扩展参数
     *
     */
    public static void onPageParameters(Map<String ,String> pageParameters) {

        FUTSDK.getInstance(context).setPageParameters(pageParameters);

    }

    /**
     * 初始化Event
     */
    private static void initEvent(String eventName) {

        FUTSDK.getInstance(context).initEvent(eventName);

    }
    /**
     * 初始化Event 传eventType
     */
    private static void initEvent(String eventName,String eventType) {

        FUTSDK.getInstance(context).initEvent(eventName,eventType);

    }
//    /**
//     * 初始化EventinitEventWithPageName
//     */
//    private static void initEventWithPageName(String eventName,String pageName) {
//
//        FUTSDK.getInstance(context).initEventWithPageName(eventName,pageName);
//
//    }
    /**
     * 加入自定义envent
     * @param pageParameters
     *
     */
    private static void onEventParameters(Map<String ,String> pageParameters) {

        FUTSDK.getInstance(context).setEventParameters(pageParameters);

    }

//    /**
//     * onEvent
//     */
//    public static void onEventWithPageName(String eventName, String pageName,Map<String ,String> pageParameters) {
//        initEventWithPageName(eventName,pageName);
//        onEventParameters(pageParameters);
//
//    }

    public  static void onEvent(String eventName,String eventType,Map<String ,String> eventParameters) {

        initEvent(eventName, eventType);
        onEventParameters(eventParameters);
    }
    public  static void onEvent(String eventName,Map<String ,String> eventParameters){
        initEvent(eventName);
        onEventParameters(eventParameters);
    }
    public  static  String getPageNameForActivity(Activity activity){
        if (activity == null){
            return null;
        }

        return getPageName(activity);
    }
    public  static  String getPageNameForFrament(Fragment fragment){
        if (fragment == null){
            return null;
        }

        return getPageName(fragment);
    }

    public  static String getPageName(Object o) {

       String pageName= "";
        if (FUTAnalyticeInterface.class.isAssignableFrom(o.getClass())) {
            pageName = ((FUTAnalyticeInterface) o).getPageName();
        }
        if (pageName==null||pageName.length()==0){
            pageName = FUTAnalytics.getRegisterFUTPageName(o.getClass().getSimpleName());

        }

    return pageName;

     }

    public static String getRegisterFUTPageName(String pageClassName){

      String pageName ="";
       PageInfo pageInfo = pageInfoMap.get(pageClassName);
       if (pageInfo!=null) {
            pageName = pageInfo.getPageName();
           if (pageName==null){

               pageName ="";
           }
       }
       return pageName;
    }

    public  static void startActivity(Activity activity,Intent intent){

        if (activity == null){
            return;
        }
        // 当前页面的名称
        String currPageName = FUTAnalytics.getPageNameForActivity(activity);

        String referPageName = activity.getIntent().getStringExtra(FUTAnalyticsConfig.REFERPAGENAME);


        if (FUTAnalyticsConfig.DEBUG) {
            Page currPage = DataConstruct.getPage();

        if (currPage!=null) {


        if (currPage.getEt() != null) {
            Log.e("FUTAnalytics", "程序检查：startActivity前页面记录异常");
        }
        String pi = currPage.getPi();
        if (pi==null||!pi.equals(currPageName)){
            Log.e("FUTAnalytics", "程序检查：页面名称异常");

        }
        String refer = currPage.getS();
        if (refer==null||!currPage.getS().equals(referPageName)){
            Log.e("FUTAnalytics", "程序检查：页面来源异常(1、首页，2、房产头条，3、天下聊消息，4、天下聊联系人，5、我的 忽略)");

        }
    }
}
        if (currPageName!=null&&currPageName.length()!=0) {
            intent.putExtra(FUTAnalyticsConfig.REFERPAGENAME, currPageName);
        }
        if (referPageName!=null&&referPageName.length()!=0) {
            intent.putExtra(FUTAnalyticsConfig.BEFOREREFERPAGENAME, referPageName);
        }

//        if (FUTAnalyticsConfig.DEBUG){
//            Log.i("FUTAnalytics", "startActivity: "+currPageName+"|"+referPageName);
//        }
    }

    public  static void xiaoMICaidan(){

      FUTSDK.getInstance(context).xiaoMICaidan();

    }

    public static void saveCrashInfoToFile(Throwable ex) {

        FUTSDK.getInstance(context).saveCrashInfoToFile(ex);

    }
}
