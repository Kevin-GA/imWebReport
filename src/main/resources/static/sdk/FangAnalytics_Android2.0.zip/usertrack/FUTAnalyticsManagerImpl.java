package com.fang.usertrack;

import android.content.Context;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.util.Log;

import com.fang.usertrack.db.helper.DataConstruct;
import com.fang.usertrack.db.helper.StaticsAgent;
import com.fang.usertrack.model.DataBlock;
import com.fang.usertrack.model.HeadModel;
import com.fang.usertrack.model.HeadModelCrash;
import com.fang.usertrack.model.LogDataModel;
import com.fang.usertrack.model.Page;
import com.fang.usertrack.observer.FangObserverPresenter;
import com.fang.usertrack.util.JsonObjUtil;
import com.soufun.app.PreferenceConstants;
import com.soufun.app.net.Apn;
import com.soufun.app.utils.StringUtils;

import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

/**
 * Created by liuxiao on 2017/11/15.
 */

public class FUTAnalyticsManagerImpl implements FUTAnalyticsManager, FangObserverPresenter.ScheduleListener {
    private Context mContext;
    /**
     * sInstance
     */
    private static FUTAnalyticsManager sInstance;
    private static FangObserverPresenter paObserverPresenter;
    private FUTAnalyticsInterfaceListener headListener;
    private FUTAnalyticsPollMgr statiPollMgr;
    private StaticsAgent agent;

    private static final String PAGE_CONFIG_FILE_NAME = "FUTAnalytics_pages.json";

    HashMap<String, String> pageIdMaps = new HashMap<String, String>();
    /**
     * Log TAG
     */
    private static final String LOGS_TAG = FUTAnalyticsPollMgr.class.getSimpleName();

    private static final ScheduledExecutorService worker =
            Executors.newSingleThreadScheduledExecutor();


    private String session_id;
    private String start_time;

    public FUTAnalyticsManagerImpl(Context mContext) {

        this.mContext = mContext;


    }

    @Override
    public boolean onInit(FUTAnalyticsInterfaceListener headListener) {


        this.headListener = headListener;
        // init  StatiPoll
        statiPollMgr = new FUTAnalyticsPollMgr(this);
        return true;
    }

    /**
     * onScheduleTimeOut
     */
    void onScheduleTimeOut() {

        Log.d(LOGS_TAG, "onScheduleTimeOut  is sendData");

        onSend();
    }

    /**
     * 按时间轮询判断日志是否需要上传
     */
    public void startSchedule() {
        // if debug  time is 5 min
        if (FUTAnalyticsConfig.DEBUG &&
                FUTAnalytics.uploadPolicy == FUTAnalytics.UploadPolicy.UPLOAD_POLICY_DEVELOPMENT) {
//            statiPollMgr.start(5* 1000);
//            Log.d(LOGS_TAG, "Schedule is start");
        } else {

//            statiPollMgr.start(FUTAnalytics.UPLOAD_TIME_ONE * 60 *1000);


        }
    }

    /**
     * checkValidId
     *
     * @param name activitiyname
     * @return pageId
     */
    private String checkValidId(String name) {
        if (TextUtils.isEmpty(name)) {
            return null;
        }
        if (name.length() <= 0) {
            return null;
        }

        return getPageId(name);
    }

    public void onSendHistory() {
        // TODO: 2017/11/23

        String historyLogs = StaticsAgent.getHistoryLog(mContext, FUTAnalyticsConfig.UTAnalytics_logs);

        if (historyLogs != null && historyLogs.length() > 0) {
            StringBuffer allJsonLog = new StringBuffer();
            allJsonLog.append("[");
            allJsonLog.append(historyLogs);
            allJsonLog.append("]");
            FUTAnalyticsNetEngine.getInstance().postHistoryJson(headListener.getServiceUrl(), FUTAnalyticsConfig.SDKUT, headListener.getHeadMaps(), mContext, allJsonLog.toString(), FUTAnalyticsConfig.UTAnalytics_logs );
        }

    }

    /*
    * 发送崩溃日志到服务器
    * */

    public void onSendException() {

        String strlog = StaticsAgent.getHistoryLog(mContext, FUTAnalyticsConfig.CrashAnalytics_logs);
        if(null != strlog && strlog.length() > 0) {
            Log.i("FUTAnalytics", "文件carsh_log==: " + strlog);
            FUTAnalyticsNetEngine.getInstance().postHistoryJson(headListener.getServiceUrl(), FUTAnalyticsConfig.SDKCRASH, headListener.getHeadMaps(), mContext, strlog, FUTAnalyticsConfig.CrashAnalytics_logs);
        }
    }

    @Override
    public void onSend() {
        StringBuffer allJsonLog = saveUTLog();
        if (allJsonLog == null) return;

        FUTAnalyticsNetEngine.getInstance().postHistoryJson(headListener.getServiceUrl(), FUTAnalyticsConfig.SDKUT, headListener.getHeadMaps(), mContext, allJsonLog.toString(), FUTAnalyticsConfig.UTAnalytics_logs);


    }

    @Nullable
    private StringBuffer saveUTLog() {
        DataBlock dataBlock = agent.getDataBlock();
        if (dataBlock == null) {
            return null;
        }


        LogDataModel logDataModel = new LogDataModel();
        logDataModel.head = headListener.getHeadModel();
        logDataModel.body = dataBlock;
        String logJson = JsonObjUtil.toJSONString(logDataModel);
        String historyLogs = StaticsAgent.getHistoryLog(mContext, FUTAnalyticsConfig.UTAnalytics_logs);

        StringBuffer allJsonLog = new StringBuffer();
        allJsonLog.append("[");
        if (historyLogs != null && historyLogs.length() > 0) {

            allJsonLog.append(historyLogs);
            allJsonLog.append(",");

        }
        allJsonLog.append(logJson);
        allJsonLog.append("]");

        // 发送前保存日志，成功后删除
        DataConstruct.saveData(mContext, logJson);
        return allJsonLog;
    }

    @Override
    public void onStore() {
        DataConstruct.storeEvent(agent);
        DataConstruct.storePage(agent);
    }

    @Override
    public void onRelease() {
        if (paObserverPresenter != null) {
            paObserverPresenter.destroy();
        }

        stopSchedule();

    }

    /**
     * getPageId
     *
     * @param clazz
     * @return
     */
    private String getPageId(String clazz) {
        if (mContext == null) {
            return null;
        }
        return pageIdMaps.get(clazz);
    }

    /**
     * stop Schedule
     */
    public void stopSchedule() {

//        Log.d(LOGS_TAG, "stopSchedule()");

        statiPollMgr.stop();
    }

    @Override
    public void onStart() {
//        Log.d(LOGS_TAG, "startSchedule");

        startSchedule();

    }

    @Override
    public void onStop() {

        stopSchedule();
    }

    @Override
    public void onReStart() {
        // stopSchedule
        stopSchedule();
        // startSchedule
        startSchedule();
    }


    @Override
    public void onRecordAppStart() {
        //send
        onSendHistory();
        onSendException();
        // init StaticsAgent

        session_id = UUID.randomUUID().toString();
        start_time = String.valueOf(System.currentTimeMillis());

        agent = new StaticsAgent();
        agent.init(mContext, session_id, start_time);

    }

    @Override
    public void onRrecordPageEnd() {
        Page currPage = DataConstruct.getPage();
        if (currPage == null) {
            if (FUTAnalyticsConfig.DEBUG) {
                Log.e("FUTAnalytics", "程序检查：页面结束统计异常");
            }
            return;
        }
        String endTime = currPage.getEt();
        if (endTime != null) {
            if (FUTAnalyticsConfig.DEBUG) {
                Log.e("FUTAnalytics", "程序检查：页面结束统计异常");
            }
            return;
        }
        int count = DataConstruct.storePage(agent);
        preSend(count);

    }

    @Override
    public void onRecordPageStart(Context context) {

        this.onRecordPageStart(context, null, null, null);

    }

    @Override
    public void onRecordPageStart(Context context, String currPageName, String referPageName, String referreferPageName) {
        if (context == null) {
            return;
        }
//        String pageId = checkValidId(context.getClass().getSimpleName());
//        if (pageId == null) {// 没有配置的页面不统计
//          return;
//        }
        //开始计时todo
        // TODO: 2017/11/23
        //       startSchedule();

        // 初始化页面数据
        // init page
        onInitPage(currPageName, referPageName, referreferPageName, headListener.getCity(), headListener.getX(), headListener.getY());

//        if (paObserverPresenter != null) {
//            paObserverPresenter.init(mContext);
//        }
//
//        if (paObserverPresenter != null) {
//            paObserverPresenter.onStart(mContext);
//        }
    }

    public void onUpdatePageName(String currPageName) {

    }


    @Override
    public void onRrecordAppEnd() {
        //recard APP exit
        if (null != agent){
            DataConstruct.storeAppAction(agent);

            onSend();
        }
//        onRelease();
    }

    @Override
    public void onInitPage(String... strings) {
        DataConstruct.initPage(mContext, strings[0], strings[1], strings[2], strings[3], strings[4], strings[5]);
    }

    @Override
    public void onPageParameters(Map<String, String> pageParameters) {
        if (FUTAnalyticsConfig.DEBUG) {

            Page currPage = DataConstruct.getPage();
            if (currPage != null && currPage.getEt() != null) {
                Log.e("FUTAnalytics", "程序检查：页面参数记录异常");
            }
        }

        DataConstruct.initPageParameter(pageParameters);

    }

    @Override
    public void onInitEvent(String eventName) {
        DataConstruct.initEvent(eventName, headListener.getCity(), headListener.getX(), headListener.getY());

    }
    @Override
    public void onInitEvent(String eventName,String eventType) {
        DataConstruct.initEvent( eventName,eventType,headListener.getCity(),headListener.getX(),headListener.getY());

    }

//    @Override
//    public void onInitEventWithPageName(String eventName,String pageName) {
//        DataConstruct.initEventWithPageName( eventName,pageName);
//
//    }

    @Override
    public void onEventParameters(Map<String, String> eventParameters) {
        if (FUTAnalyticsConfig.DEBUG) {

            Page currPage = DataConstruct.getPage();

            if (currPage != null && currPage.getEt() != null) {
                Log.e("FUTAnalytics", "程序检查：事件参数记录异常");
            }
        }

        DataConstruct.onEvent(eventParameters);

        // 目前支持即时事件。设置完参数后就保存事件。

        int count = DataConstruct.storeEvent(agent);

        preSend(count);


    }

    public void preSend(int count) {

        if (count >= FUTAnalyticsConfig.limitCountFor4G) {
            if (headListener.getNetWorkType().equals("4G")) {
                onSend();
                agent = new StaticsAgent();
                agent.init(mContext, session_id, start_time);
            }
        }

        if (count >= FUTAnalyticsConfig.limitCountForWifi) {
            if (headListener.getNetWorkType().equals("wifi")) {
                onSend();
                agent = new StaticsAgent();
                agent.init(mContext, session_id, start_time);
            }
        }

    }

    public FUTAnalyticsInterfaceListener getInterfaceListener() {

        return headListener;
    }

    public void xiaoMICaidan() {

        onRrecordAppEnd();
        session_id = UUID.randomUUID().toString();
        start_time = String.valueOf(System.currentTimeMillis());

        agent = new StaticsAgent();
        agent.init(mContext, session_id, start_time);

    }

    @Override
    public void saveCrashInfoToFile(Throwable ex) {
        // 崩溃时保存当前的用户行为日志。
        String utjsonlog = saveUTLog().toString();

        HeadModelCrash headModelCrash = new HeadModelCrash();
        //获取head信息
        headModelCrash = getHeadInfo(headModelCrash);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US);
        headModelCrash.crashtime = simpleDateFormat.format(new Date());
        //获取ex的base64编码
        String exbase64 = getCrashInfo(ex);
        headModelCrash.detail = exbase64;
        headModelCrash.utjsonlog = utjsonlog;
        String crashJsonLog = JsonObjUtil.toJSONString(headModelCrash);

        StringBuffer crashBuffer = new StringBuffer();
        crashBuffer.append(crashJsonLog);
        //保存崩溃日志
        StaticsAgent.saveCrashLogFile(mContext,crashBuffer.toString());
    }

    private String getCrashInfo(Throwable ex) {
        // 获得错误信息
        Writer writer = new StringWriter();
        PrintWriter printWriter = new PrintWriter(writer);
        ex.printStackTrace(printWriter);
        Throwable cause = ex.getCause();
        while (cause != null) {// 循环，把所有的cause都输出到printWriter中
            cause.printStackTrace(printWriter);
            cause = cause.getCause();
        }
        printWriter.close();
        String result = writer.toString();
        return StaticsAgent.getUidFromBase64(result);
    }

    private HeadModelCrash getHeadInfo(HeadModelCrash headModelCrash) {

        HeadModel head = headListener.getHeadModel();
        headModelCrash.version = head.version;
        headModelCrash.buildversion = PreferenceConstants.PATCH_TAG;
        headModelCrash.appname = head.appname;
        headModelCrash.userid = head.userid;
        headModelCrash.sdkversiom = head.getSdkversion();
        headModelCrash.company = head.company;
        headModelCrash.phonenumber = head.phonenumber;
        headModelCrash.networktype = head.networktype;
        headModelCrash.imei = head.imei;
        headModelCrash.username = head.username;
        headModelCrash.model = head.model;
        headModelCrash.osversion = head.osversion;
        headModelCrash.city = headListener.getCity();
        return headModelCrash;
    }

}
