package com.fang.usertrack;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.util.Log;

import com.fang.usertrack.util.MIUIUtils;

import java.util.Map;

/**
 * Created by liwei on 2017/11/15.
 */

public class FUTSDK {

    /** context */
    private Context mContext;
    /** Instance */
    private static FUTSDK sInstance;

    private static final String TAG = "FUTAnalytics::FUTSDK";

    private FUTAnalyticsManager staticsManager;
    private MyReceiver receiver = new MyReceiver();
    private class MyReceiver extends BroadcastReceiver {

        private final String SYSTEM_DIALOG_REASON_KEY = "reason";
        private final String SYSTEM_DIALOG_REASON_HOME_KEY = "homekey";
        private final String SYSTEM_DIALOG_REASON_RECENT_APPS = "recentapps";

        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (action.equals(Intent.ACTION_CLOSE_SYSTEM_DIALOGS)) {
                String reason = intent.getStringExtra(SYSTEM_DIALOG_REASON_KEY);

                if (reason == null)
                    return;

                // 最近任务列表键
                if (reason.equals(SYSTEM_DIALOG_REASON_RECENT_APPS)) {

                    if (MIUIUtils.getSystem().equals(MIUIUtils.SYS_MIUI)) {
                        FUTAnalytics.xiaoMICaidan();

                    }
                    Log.i("FUTAnalytics", "onReceive: 小米多任务菜单");
                }
            }
        }
    }
    /**
     *  getInstance
     * @param aContext
     * @return
     */
    public static synchronized FUTSDK getInstance(Context aContext) {
        if (sInstance == null) {
            sInstance = new FUTSDK(aContext,  new FUTAnalyticsManagerImpl(aContext));
        }
        return sInstance;
    }
     /**
      * constructor
      *
      * @param aContext
      *
     */
    private FUTSDK(Context aContext, FUTAnalyticsManager aStaticsManager) {
        mContext = aContext;
        staticsManager = aStaticsManager;

    }

    protected void init(FUTAnalyticsInterfaceListener headListener) {

        staticsManager.onInit(headListener);

        receiver = new MyReceiver();

        IntentFilter homeFilter = new IntentFilter(Intent.ACTION_CLOSE_SYSTEM_DIALOGS);

        mContext.registerReceiver(receiver, homeFilter);

    }

    public void send() {

        staticsManager.onSend();
    }

    protected void store() {

        staticsManager.onStore();

    }

    protected void upLoad() {

        staticsManager.onSend();
    }

    /**
     * release
     */
    protected void release() {

        staticsManager.onRelease();

    }

    protected void recordPageEnd() {

        staticsManager.onRrecordPageEnd();

    }

    protected void recordAppStart() {

        staticsManager.onRecordAppStart();

    }

    protected void recordAppEnd() {

        staticsManager.onRrecordAppEnd();

    }

    protected void recordPageStart(Context context) {

        staticsManager.onRecordPageStart(context);

    }
    protected  void recordPageStart(Context context,String currPageName,String referPageName,String referreferPageName){
        staticsManager.onRecordPageStart(context,currPageName,referPageName,referreferPageName);
    }

    protected void setPageParameters(Map<String,String> pageParameters) {

        staticsManager.onPageParameters(pageParameters);

    }

    protected void initEvent(String envntName) {

        staticsManager.onInitEvent(envntName);

    }
    protected void initEvent(String envntName,String enventType) {

        staticsManager.onInitEvent(envntName,enventType);

    }


    protected void setEventParameters(Map<String,String> pageParameters) {

        staticsManager.onEventParameters(pageParameters);

    }

    protected void initPage(String pageName, String referPageName,String referferPageName) {

        staticsManager.onInitPage(pageName, referPageName,referferPageName);

    }

    protected FUTAnalyticsInterfaceListener getIntergaceListener(){

       return staticsManager.getInterfaceListener();
    }

    protected void xiaoMICaidan(){
        staticsManager.xiaoMICaidan();
    }

    protected void saveCrashInfoToFile(Throwable ex) {
        staticsManager.saveCrashInfoToFile(ex);
    }
}