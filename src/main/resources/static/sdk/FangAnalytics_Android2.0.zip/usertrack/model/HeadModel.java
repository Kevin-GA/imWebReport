package com.fang.usertrack.model;

import com.fang.usertrack.FUTAnalyticsConfig;

/**
 * Created by liwei on 2017/11/24.
 *  "city": "北京",
 "company": "32057",
 "phonenumber": "13716823534",
 "user-agent": "Android_UnMap%7EHTC+U-1w%7E7.0",
 "userid": "41714304",
 "networktype": "wifi",
 "app-name": "Android_UnMap",
 "username": "justingnn",
 "imei": "3.56123E+14",
 "version": "7",
 "y1": "39.820099",
 "x1": "116.306967",
 "model": "HTC+U-1w",
 "carrier": "移动",
 "sdkversion": “1.0"
 */

public class HeadModel {
    public String company;
    public String phonenumber;
    public String useragent;
    public String userid;
    public String networktype;
    public String appname;
    public String username;
    /*app版本号*/
    public String version;
    /*手机厂商型号*/
    public String model;
    /*运营商*/
    public String carrier;
    /*sdk版本*/
    private String sdkversion;
    public String osversion;
    public String imei;

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }



    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber;
    }

    public String getUseragent() {
        return useragent;
    }

    public void setUseragent(String useragent) {
        this.useragent = useragent;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getNetworktype() {
        return networktype;
    }

    public void setNetworktype(String networktype) {
        this.networktype = networktype;
    }

    public String getAppname() {
        return appname;
    }

    public void setAppname(String appname) {
        this.appname = appname;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }



    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getCarrier() {
        return carrier;
    }

    public void setCarrier(String carrier) {
        this.carrier = carrier;
    }

    /* sdk统一版本号 */
    public String getSdkversion() {
        return FUTAnalyticsConfig.SDKVERSION;
    }

    public String getOsversion() {
        return osversion;
    }

    public void setOsversion(String osversion) {
        this.osversion = osversion;
    }
}
