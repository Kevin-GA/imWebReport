package com.fang.usertrack.model;

import java.util.ArrayList;
import java.util.List;

/**
 * 页面数据统计集合
 * Created by liwei on 2017-11-17.
 */
public class PageList {
    private List<Page> list ;

    public List<Page> getList() {
        if (list==null){
            list =  new ArrayList<Page>();

        }
        return list;

    }

    public void setList(List<Page> list) {
        this.list = list;
    }
}
