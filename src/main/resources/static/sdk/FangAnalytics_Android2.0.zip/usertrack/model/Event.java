package com.fang.usertrack.model;

import java.security.PrivateKey;
import java.util.List;
import java.util.Map;

/**
 * 对应的event事件
 * Created by liwei on 2017-11-17.
 */
public class Event {
    private String pi ;
    private String eventname ;
    private String time ;
    private String eventtype;
    private String city;
    private String x1;
    private String y1;

    private Map<String,String> ext ;

    public String getPi() {
        return pi;
    }

    public void setPi(String pi) {
        this.pi = pi;
    }

    public Map<String, String> getExt() {
        return ext;
    }

    public void setExt(Map<String, String> ext) {
        this.ext = ext;
    }

    public String getEventname() {
        return eventname;
    }

    public void setEventname(String eventname) {
        this.eventname = eventname;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getEventtype() {
        return eventtype;
    }

    public void setEventtype(String eventtype) {
        this.eventtype = eventtype;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getX1() {
        return x1;
    }

    public void setX1(String x1) {
        this.x1 = x1;
    }

    public String getY1() {
        return y1;
    }

    public void setY1(String y1) {
        this.y1 = y1;
    }

    @Override
    public String toString() {
        return "Event{" +
                "pi='" + pi + '\'' +
                ", eventname='" + eventname + '\'' +
                ", time='" + time + '\'' +
                ", eventtype='" + eventtype + '\'' +
                ", city='" + city + '\'' +
                ", x1='" + x1 + '\'' +
                ", y1='" + y1 + '\'' +
                ", ext=" + ext +
                '}';
    }
}
