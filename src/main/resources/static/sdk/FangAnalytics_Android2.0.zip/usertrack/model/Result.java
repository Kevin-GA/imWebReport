package com.fang.usertrack.model;

/**
 * Created by user on 2017/12/6.
 */

public class Result {
    String result;

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }
}
