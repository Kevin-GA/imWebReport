package com.fang.usertrack.model;

/**

 * Created by liwei on 2017-11-17.
 */
public class AppAction {
    private String action_time ;
    private String app_action_type ;
    private String session_id;

    public String getAction_time() {
        return action_time;
    }

    public void setAction_time(String action_time) {
        this.action_time = action_time;
    }

    public String getApp_action_type() {
        return app_action_type;
    }

    public void setApp_action_type(String app_action_type) {
        this.app_action_type = app_action_type;
    }

    public String getSession_id() {
        return session_id;
    }

    public void setSession_id(String session_id) {
        this.session_id = session_id;
    }

    @Override
    public String toString() {
        return "AppAction{" +
                "action_time='" + action_time + '\'' +
                ", app_action_type='" + app_action_type + '\'' +
                ", session_id='" + session_id + '\'' +
                '}';
    }
}
