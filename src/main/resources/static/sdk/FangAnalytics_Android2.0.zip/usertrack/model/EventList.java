package com.fang.usertrack.model;

import java.util.ArrayList;
import java.util.List;

/**
 * 对应的event事件集合
 * Created by liwei on 2017-11-17.
 */
public class EventList {
    private List<Event> list ;

    public List<Event> getList() {
        if (list==null){
            list =  new ArrayList<Event>();

        }
        return list;
    }

    public void setList(List<Event> list) {
        this.list = list;
    }
}
