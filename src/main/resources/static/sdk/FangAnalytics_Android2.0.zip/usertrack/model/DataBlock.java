package com.fang.usertrack.model;

import java.util.List;

/**
 * 上传数据对象bean
 * "session_id": "070771235AF34490B26DD0E4509FD0E4D341A”, 会话ID
 "start_time": "15096785051234”,  会话开始时间
 "end_time": "15096786376234”, 会话结束时间  当没切后台就超过50条提交时，结束时间会为空
 "duration": "234234”,                  会话持续时间
 "pages": [],                                  会话期间访问的页面
 “events": []                                  会话期间产生的事件
 * Created by liwei on 2017-11-17.
 */
public class DataBlock {
    private String  session_id;
    private String start_time;
    private String end_time;
    private String duration;

    private List<Page> pages;
    private List<Event> events;

    public String getStart_time() {
        return start_time;
    }

    public void setStart_time(String start_time) {
        this.start_time = start_time;
    }

    public String getEnd_time() {
        return end_time;
    }

    public void setEnd_time(String end_time) {
        this.end_time = end_time;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getSession_id() {

        return session_id;
    }

    public void setSession_id(String session_id) {
        this.session_id = session_id;
    }

    public List<Page> getPages() {
        return pages;
    }

    public void setPages(List<Page> pages) {
        this.pages = pages;
    }

    public List<Event> getEvents() {
        return events;
    }

    public void setEvents(List<Event> events) {
        this.events = events;
    }
}
