package com.fang.usertrack.model;

import java.util.ArrayList;
import java.util.List;

/**
 * AppAction
 * Created by liwei on 2017-11-17.
 */
public class AppActionList {
    private List<AppAction> list ;

    public List<AppAction> getList() {
        if (list==null){
            list =  new ArrayList<AppAction>();

        }
        return list;
    }

    public void setList(List<AppAction> list) {
        this.list = list;
    }
}
