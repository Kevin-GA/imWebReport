package com.fang.usertrack.model;

/**
 * Created by liwei on 2017/11/23.
 */

public class LogDataModel extends Object {
    public  HeadModel head;
    public  DataBlock body;

    public HeadModel getHead() {
        return head;
    }

    public void setHead(HeadModel head) {
        this.head = head;
    }

    public DataBlock getBody() {
        return body;
    }

    public void setBody(DataBlock body) {
        this.body = body;
    }
}
