package com.fang.usertrack.model;

/**
 * Created by mazhanshan on 2018/3/20.
 */

public class HeadModelCrash{

    public String version;
    public String buildversion;//
    public String appname;
    public String userid;
    public String sdkversiom;
    public String company;
    public String phonenumber;
    public String networktype;
    public String imei;
    public String username;
    public String model;
    public String osversion;
    public String crashtime;//
    public String detail;//
    public String city;//
    public String utjsonlog;// 上传崩溃时操作日志流程


}
