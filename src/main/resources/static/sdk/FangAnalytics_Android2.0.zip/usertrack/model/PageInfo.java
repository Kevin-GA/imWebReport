package com.fang.usertrack.model;

/**
 * Created by user on 2017/12/7.
 */

public class PageInfo {
    /**
     * 页面编号
     */
    String pageClass;
    /**
     * 页面名称
     */
    String pageName;

    /**
     * 页面类型
     * 1、一种不需要写代码只需继承基类
     2、一种需要继承基类重写getPageName方法
     3、自己判断页面显隐时机，分别调用recoredPageStart方法与recoredPageEnd方法，
     如果没继承基类的话，还要自己在跳转其他页面之前在Intent中设置页面与来源传给下个页面，
     如果继承基类就不用处理了
     */
    String pageType;

    public String getPageName() {
        return pageName;
    }

    public void setPageName(String pageName) {
        this.pageName = pageName;
    }

    public String getPageClass() {
        return pageClass;
    }

    public void setPageClass(String pageClass) {
        this.pageClass = pageClass;
    }

    public String getPageType() {
        return pageType;
    }

    public void setPageType(String pageType) {
        this.pageType = pageType;
    }
}
