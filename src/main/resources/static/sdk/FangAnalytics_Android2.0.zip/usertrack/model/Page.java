package com.fang.usertrack.model;

import java.util.List;
import java.util.Map;

/**
 * Page
 * Created by liwei on 2017-11-17.
 */
public class Page {

    private String pi;//页面名称
    private String s ;// 页面来源
    private String ss ;// 来源的来源

    private String st ;// 进入页面的时间
    private String et ;// 退出页面的时间
    private String set ;// 页面停留时间
    private String city;
    private String x1;
    private String y1;

    private Map<String,String> ext ;// 页面信息扩展字段

    public String getS() {
        return s;
    }

    public void setS(String s) {
        this.s = s;
    }

    public String getSs() {
        return ss;
    }

    public void setSs(String ss) {
        this.ss = ss;
    }

    public String getSt() {
        return st;
    }

    public void setSt(String st) {
        this.st = st;
    }

    public String getEt() {
        return et;
    }

    public void setEt(String et) {
        this.et = et;
    }

    public String getSet() {
        return set;
    }

    public void setSet(String set) {
        this.set = set;
    }

    public Map<String,String> getExt() {
        return ext;
    }

    public void setExt(Map<String,String> ext) {
        this.ext = ext;
    }

    public String getPi() {
        return pi;

    }

    public void setPi(String pi) {
        this.pi = pi;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getX1() {
        return x1;
    }

    public void setX1(String x1) {
        this.x1 = x1;
    }

    public String getY1() {
        return y1;
    }

    public void setY1(String y1) {
        this.y1 = y1;
    }

    @Override
    public String toString() {
        return "Page{" +
                "pi='" + pi + '\'' +
                ", s='" + s + '\'' +
                ", ss='" + ss + '\'' +
                ", st='" + st + '\'' +
                ", et='" + et + '\'' +
                ", set='" + set + '\'' +
                ", city='" + city + '\'' +
                ", x1='" + x1 + '\'' +
                ", y1='" + y1 + '\'' +
                ", ext=" + ext +
                '}';
    }
}
