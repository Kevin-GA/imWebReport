//
//  PZLWNavigationViewController.m
//  homezxb
//
//  Created by mwq on 2018/3/2.
//  Copyright © 2018年 soufunhome. All rights reserved.
//

#import "PZLWNavigationViewController.h"

@interface PZLWNavigationViewController ()

@end

@implementation PZLWNavigationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    // 统计相关
    if ([self.topViewController isKindOfClass:[SouFunBaseViewCtrl class]] && [viewController isKindOfClass:[SouFunBaseViewCtrl class]]) {
        SouFunBaseViewCtrl *topVC = (SouFunBaseViewCtrl *)self.topViewController;
        SouFunBaseViewCtrl *nextVC = (SouFunBaseViewCtrl *)viewController;
        if (!nextVC.pageFrom) {
            nextVC.pageFrom = topVC.pageName;
        }
        if(!nextVC.pageF_From){
            nextVC.pageF_From = topVC.pageFrom;
        }
    }
    [super pushViewController:viewController animated:animated];
}

@end
