//
//  SouFunPBService.m
//  功用：页面统计
//  使用场景：页面统计时间统计FA统计
//  创建时间：2017-10-20
//  创建人：于静波
//

#import "SouFunPBService.h"
#import "Utilities.h"
#import "SouFunUserBasicInfo.h"
#import "ServiceManager.h"
#import "ASIFormDataRequest.h"
#import "SouFunAppDelegate.h"

#define STR_PBFileName @"sf_pb_file.plist"
#define STR_SDKVersion @"1.0.2"
//const NSInteger KFailNodItem = 10;  //错误情况下够10的倍数提交
const NSInteger KwifiItem = 30; //wifi环境下上传条数
const NSInteger KGItem = 50;    //非wifi环境下上传条数

@interface SouFunPBService()

@property(nonatomic, strong)NSMutableArray * pageTaskAry; //页面统计任务队列
@property(nonatomic, strong)NSMutableArray * eventTaskAry; //事件统计任务队列
@property(nonatomic, assign)UInt64 launchTime;  //进入app时间
@property(nonatomic, assign)UInt64 exitTime;    //切换到后台时间
@property(nonatomic, strong)NSString * sessionId; //每次运行的sessionID


@end

@implementation SouFunPBService

//NSMutableArray * _taskAry;  //页面停留时间任务列表
//NSMutableArray * _pageTaskAry; //页面统计任务列表
//NSMutableArray * _eventTaskAry; //事件统计任务列表
//UInt64  _launchTime;  //启动时间


static SouFunPBService * _sharedPBService = nil;


- (id)init{
    self = [super init];
    if (self) {
        _pageTaskAry = [[NSMutableArray alloc] init];
        _eventTaskAry = [[NSMutableArray alloc] init];
        
    }
    return self;
}
+(SouFunPBService *)sharedPBService
{
    @synchronized([SouFunPBService class])
    {
        if (!_sharedPBService)
            _sharedPBService = [[SouFunPBService alloc] init];
        
        return _sharedPBService;
    }
    
    return nil;
}


-(NSString *)ToJsonData:(NSMutableDictionary*)dic{
    NSError *parseError = nil;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dic options:0 error:&parseError];
    if (jsonData != nil && jsonData.length > 0) {
        NSString * JsStr = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        return JsStr;
    }
    NSString * JsStr = @"";
    return JsStr;
}

-(UInt64)getCurrTime{
    
    UInt64 currTime = [[NSDate date] timeIntervalSince1970]*1000;
    return currTime;
}
//将时间戳转化为当前时间
- (NSString *)getTimeToShowWithTimestamp:(NSString *)timestamp
{
    double publishLong = [timestamp doubleValue]/1000;
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateStyle:NSDateFormatterMediumStyle];
    [formatter setTimeStyle:NSDateFormatterShortStyle];
    [formatter setTimeZone:[NSTimeZone localTimeZone]];
    //[formatter setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"UTC"]];
    [formatter setDateFormat:@"yyyy年MM月dd日 HH:mm:ss E"];
    //  @"yyyy年MM月dd日 HH:mm:ss E"];
    NSDate *publishDate = [NSDate dateWithTimeIntervalSince1970:publishLong];
    NSString *publishString = [formatter stringFromDate:publishDate];
    
    return publishString;
}


#pragma mark --- 以下为新的行为统计SDK使用方法 ---
//事件枚举类型转字符串
-(NSString*)getEventTypeStr:(EEventType)eveType{
    switch (eveType) {
        case E_Click:
            return @"click";
        case E_Slide:
            return @"slide";
        case E_POSlide:
            return @"poslide";
        case E_ReadEnd:
            return @"readEnd";
        default:
            return @"";
    }
    return @"";
}
/*
 过滤无效页面统计数据：
 采用大导航推下级页面时，下级页面走两次viewWillDisappear：例如：当前页面用大导航跳转聊天或相册当前页面两调两次viewWillDisappear
 */
-(BOOL)orFilterInvalidPV:(NSString *)piName {
    
    if (_pageTaskAry != nil && _pageTaskAry.count > 0) {
        NSMutableDictionary * tempDic = [_pageTaskAry objectAtSafeIndex:(_pageTaskAry.count - 1)];
        NSString * tempStr = nil;
        
        if (tempDic != nil) {
            tempStr = [tempDic objectForKey:@"pi"];
        }
        if (tempStr != nil && [tempStr isEqualToString:piName]) {
            UInt64 tempInt = [self getCurrTime];
            NSString * tempet = [tempDic objectForKey:@"et"];
            UInt64 et = [tempet longLongValue];
            //两次相同的页面统计间隔时间小于1000毫秒
            if (tempInt - et <= 900) {
                //NSLog(@"======%@无效页面统计 时间差 = %lld", piName,tempInt - et);
                return YES;
            }
        }
    }
    return NO;
}
//过滤字典中的空对象
-(void)FilterDicNull:(NSMutableDictionary*)dic{
    if (dic == nil) {
        return;
    }
    NSArray * allkey = [dic allKeys];
    for (int i = 0; i < allkey.count; i++) {
        NSString * key = [allkey objectAtSafeIndex:i];
        NSString * str = [dic objectForKey:key];
        if (str == nil || ![str isKindOfClass:[NSString class]] || str.length == 0) {
            [dic removeObjectForKey:key];
        }
    }
}

+(NSString*)getFormatTJPoStr:(NSString *)subPoStr,...NS_REQUIRES_NIL_TERMINATION{
    if(STRValid(subPoStr)){
        return nil;
    }
    NSMutableString * tempstr = [[NSMutableString alloc] init];
    [tempstr appendFormat:@"%@", subPoStr];
    va_list varList;
    id arg;
    va_start(varList,subPoStr);
    while((arg = va_arg(varList,id))){
        //这里查找到可变参数中的所有参数
        if (arg != nil){
            [tempstr appendFormat:@"@!@%@",arg];
        }
    }
    va_end(varList);
    return tempstr;
}
+(NSString*)getFormatPoItemStr:(NSArray*)poAry{
    
    NSMutableString * tempStr = [[NSMutableString alloc] init];
    if (poAry && [poAry isKindOfClass:[NSArray class]] && poAry.count > 0) {
        for (int i = 0; i < poAry.count; i++) {
            if (![[poAry objectAtSafeIndex:i] isKindOfClass:[NSString class]]) {
                break;
            }
            if (i == 0) {
                [tempStr appendFormat:@"%@", [poAry objectAtSafeIndex:i]];
            }
            else{
                [tempStr appendFormat:@"||%@",[poAry objectAtSafeIndex:i]];
            }
        }
        
    }
    return tempStr;
    
}
-(NSDictionary*)getPBCommHeaderDic{
    
    NSMutableDictionary * headerDic = [[NSMutableDictionary alloc] init];
    NSString * header1 = [NSString stringWithString:[[[NSBundle mainBundle] infoDictionary] objectForKey:@"ProductName"]];
    header1= [header1 stringByAppendingString:@"~"];
    header1=[header1 stringByAppendingString:[[UIDevice currentDevice] model]];
    header1= [header1 stringByAppendingString:@"~"];
    header1=[header1 stringByAppendingString:[[UIDevice currentDevice] systemVersion]];
    [headerDic setObject:header1  forKey:@"useragent"];
    [headerDic setObject:[UtilityHelper getDeviceModel]  forKey:@"model"];
    SFun_Log(@"============请求头===========");
    
    NSString * header2 = [NSString stringWithString:[[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"]];
    [headerDic setObject:header2 forKey:@"version"];
    NSString * tempOs = [SouFunUserBasicInfo sharedSouFunUserBasicInfo].osVis;
    SL_Log(@"当前系统版本 = %@", tempOs);
    [headerDic setObject:tempOs forKey:@"osversion"];
    [headerDic setObject:STR_SDKVersion forKey:@"sdkversion"];
    NSString * imei7 = [SouFunUserBasicInfo sharedSouFunUserBasicInfo].ios7UDID;
    [headerDic setObject:imei7 forKey:@"imei"];
    [headerDic setObject:@"ios_fang" forKey:@"appname"];
    SL_Log(@"ios7imei = %@", imei7);
    SouFunUserBasicInfo * userInfo = [SouFunUserBasicInfo sharedSouFunUserBasicInfo];
    
    //渠道号
    if (userInfo.qudaohao != nil && userInfo.qudaohao.length > 0) {
        SL_Log(@"渠道号 = %@", userInfo.qudaohao);
        [headerDic setObject:userInfo.qudaohao forKey:@"company"];
    }
    // 添加网络状态
    [headerDic setObject:SFSTR(userInfo.netTypeForRequestHeader) forKey:@"networktype"];
    if ([userInfo.sFLogin_Statu isEqualToString:@"1"]) {
        [headerDic setObject:SFSTR(userInfo.sFLogin_Userid)  forKey:@"userid"];
        [headerDic setObject:SFSTR(userInfo.sFLogin_PhoneNumber) forKey:@"phonenumber"];
        [headerDic setObject:SFSTR(userInfo.sFLogin_Name) forKey:@"username"];
    }
    return headerDic;
}


-(void)addPVTJ:(NSString*)pagName pageFrom:(NSString*)pageFrom from_From:(NSString*)from_From startTime:(UInt64)startTime extDic:(NSMutableDictionary*)extDic{
    if (STRValid(pagName) || startTime<=0) {
        return;
    }
    
    
    if ([self orFilterInvalidPV:pagName]) {
        return;
    }
    [self FilterDicNull:extDic];
    //传入参数是否有特殊字符
    if (![self isIllegachar:pagName] && [self isIllegachar:from_From]) {
        return;
    }
    NSMutableDictionary * tempDic = [[NSMutableDictionary alloc] init];
    [tempDic setObject:pagName forKey:@"pi"];
    if (pageFrom != nil && pageFrom.length > 0) {
        [tempDic setObject:pageFrom forKey:@"s"];
    }
    if (from_From != nil && from_From.length > 0) {
        [tempDic setObject:from_From forKey:@"ss"];
    }
    //8.5.7大数据要求将定位坐标和城市放在页面及事件body中
    SouFunUserBasicInfo * userInfo = [SouFunUserBasicInfo sharedSouFunUserBasicInfo];
    if (userInfo.userCoordX !=nil  && userInfo.userCoordX.length >0 && userInfo.userCoordY !=nil && userInfo.userCoordY.length > 0) {
        [tempDic setObject:userInfo.userCoordX forKey:@"x1"];
        [tempDic setObject:userInfo.userCoordY forKey:@"y1"];
    }
    if (userInfo.mainCity != nil && userInfo.mainCity.length > 0) {
        [tempDic setObject:userInfo.mainCity forKey:@"city"];
    }
    NSString * tempSStr = [NSString stringWithFormat:@"%llu", startTime];
    //NSLog(@"时间戳转化后的时间 = %@", [self getTimeToShowWithTimestamp:tempStr]);
    [tempDic setObject:tempSStr forKey:@"st"];
    NSString * tempEStr = [NSString stringWithFormat:@"%llu", [self getCurrTime]];
    [tempDic setObject:tempEStr forKey:@"et"];
    UInt64 tempInt = [self getCurrTime] - startTime;
    if (tempInt > 0) {
        NSString * tempStayTime = [NSString stringWithFormat:@"%llu",tempInt];
        [tempDic setObject:tempStayTime forKey:@"set"];
    }
    if (extDic != nil && extDic.count >0) {
        [tempDic setObject:extDic forKey:@"ext"];
    }
    [_pageTaskAry addObject:tempDic];
    [self submitPB];
    //[self PBTJPostRequest:YES];
    
}

-(void)addEventTJ:(NSString*)eveName pageName:(NSString*)pageName eveType:(EEventType)eveType extDic:(NSMutableDictionary*)extDic{
    
    if (STRValid(eveName) || STRValid(pageName)) {
        return;
    }
    //传入参数是否有特殊字符
    if (![self isIllegachar:eveName] && [self isIllegachar:pageName]) {
        return;
    }
    [self FilterDicNull:extDic];
    NSMutableDictionary * tempDic = [[NSMutableDictionary alloc] init];
    [tempDic setObject:eveName forKey:@"eventname"];
    [tempDic setObject:pageName forKey:@"pi"];
    [tempDic setObject:[self getEventTypeStr:eveType] forKey:@"eventtype"];
    //8.5.7大数据要求将定位坐标和城市放在页面及事件body中
    SouFunUserBasicInfo * userInfo = [SouFunUserBasicInfo sharedSouFunUserBasicInfo];
    if (userInfo.userCoordX !=nil  && userInfo.userCoordX.length >0 && userInfo.userCoordY !=nil && userInfo.userCoordY.length > 0) {
        [tempDic setObject:userInfo.userCoordX forKey:@"x1"];
        [tempDic setObject:userInfo.userCoordY forKey:@"y1"];
    }
    if (userInfo.mainCity != nil && userInfo.mainCity.length > 0) {
        [tempDic setObject:userInfo.mainCity forKey:@"city"];
    }
    NSString * tempEStr = [NSString stringWithFormat:@"%llu", [self getCurrTime]];
    [tempDic setObject:tempEStr forKey:@"time"];
    if (extDic != nil && extDic.count > 0) {
        [tempDic setObject:extDic forKey:@"ext"];
    }
    [_eventTaskAry addObject:tempDic];
    [self submitPB];
}

+(void)FATJ:(NSString*)eveName pageName:(NSString*)pageName{
    [[SouFunPBService sharedPBService] addEventTJ:eveName pageName:pageName eveType:E_Click extDic:nil];
}

-(void)SFLanuchPBTJ{
    _launchTime = [self getCurrTime];
    _exitTime = 0;
    _sessionId =  [[NSUUID UUID] UUIDString];
    [self removeAllPBTask];
    //判断是否有上次未提交数据
    [self subHistoryPB];
    //NSLog(@"=====SFLanuchPBTJ====");
}
-(void)SFSubExitPBTJ{
    
    _exitTime = [self getCurrTime];
    ////切入后台时延时调用，由于applicationWillResignActive 比applicationDidEnterBackground先执行，会丢失当前页面的页面事件
    [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(timerDeal:) userInfo:nil repeats:NO];
    
}
-(void)timerDeal:(NSTimer*)timer{
    [timer invalidate];
    NSString * jsonStr = [self getPBTaskJson];
    [self PBTJPostRequest:jsonStr];
    //NSLog(@"=====SFSubExitPBTJ====");
}
-(NSString*)catchPBJson:(NSMutableArray*)PBAry{
    
    NSMutableString * TjStr = [[NSMutableString alloc] init];
    [TjStr appendString:@"["];
    for (int i = 0; i<PBAry.count; i++) {
        NSMutableDictionary * dic = [PBAry objectAtSafeIndex:i];
        NSString * tempStr = [self ToJsonData:dic];
        if (tempStr != nil && tempStr.length > 0) {
            if (i == PBAry.count - 1) {
                [TjStr appendString:tempStr];
            }
            else{
                [TjStr appendFormat:@"%@,", tempStr];
            }
        }
        
    }
    [TjStr appendString:@"]"];
    return TjStr;
    
}
//传入参数是否有非法字符
-(BOOL)isIllegachar:(NSString*)str{
    if ([str containsString:@"["] || [str containsString:@"]"]
        || [str containsString:@"{"] || [str containsString:@"}"]
        || [str containsString:@"\""]) {
        return YES;
    }
    return NO;
}

/*
 功能：获得本次PB统计json
 */
-(NSString*)getPBTaskJson{
    
    //历史json读文件
    NSMutableArray * pbAry = [self ReadPBFile];
    if (pbAry != nil) {
        NSMutableDictionary * jsonDic = [[NSMutableDictionary alloc] init];
        [jsonDic setObject:[self getPBCommHeaderDic] forKey:@"head"];
        [jsonDic setObject:[self getPBbodyDic] forKey:@"body"];
        [pbAry addObject:jsonDic];
    }
    return [self catchPBJson:pbAry];
}
/*
 功能：获得提交bodyjson
 */
-(NSDictionary*)getPBbodyDic{
    
    NSMutableDictionary * bodyDic = [[NSMutableDictionary alloc] init];
    [bodyDic setObject:SFSTR(_sessionId) forKey:@"session_id"];
    NSString * tempLanuchTime = [NSString stringWithFormat:@"%llu", _launchTime];
    [bodyDic setObject:SFSTR(tempLanuchTime) forKey:@"start_time"];
    if (_exitTime > 0) {
        NSString * tempEStr = [NSString stringWithFormat:@"%llu", _exitTime];
        [bodyDic setObject:tempEStr forKey:@"end_time"];
        UInt64 tempInt = _exitTime - _launchTime;
        if (tempInt > 0) {
            NSString * tempStayTime = [NSString stringWithFormat:@"%llu",tempInt];
            [bodyDic setObject:tempStayTime forKey:@"duration"];
        }
    }
    if (_pageTaskAry != nil && _pageTaskAry.count > 0) {
        [bodyDic setObject:_pageTaskAry forKey:@"pages"];
    }
    if (_eventTaskAry != nil && _eventTaskAry.count > 0) {
        [bodyDic setObject:_eventTaskAry forKey:@"events"];
    }
    return bodyDic;
    
}
//是否满足提交条件
-(BOOL)isMeetConditions{

    SouFunUserBasicInfo * userInfo = [SouFunUserBasicInfo sharedSouFunUserBasicInfo];
    //wifi情况下够30条提交
    if ([userInfo.netTypeForRequestHeader isEqualToString:@"wifi"]) {
        if ((_pageTaskAry.count + _eventTaskAry.count) >= KwifiItem) {
            return YES;
        }
    }
    else{
        if ((_pageTaskAry.count + _eventTaskAry.count) >= KGItem) {
            return YES;
        }
    }
    return NO;
}
//运行中提交统计
-(void)submitPB{
    if (![self isMeetConditions]) {
        return;
    }
    NSString * jsonStr = [self getPBTaskJson];
    [self PBTJPostRequest:jsonStr];
    
}
//提交历史数据
-(void)subHistoryPB{
    NSMutableArray * ary = [self ReadPBFile];
    if (ary != nil && ary.count > 0) {
        [self PBTJPostRequest:[self catchPBJson:ary]];
    }
}
//提交页面行为统计请求（退到后台时做无条件提交，其他情况做有条件提交）
-(void)PBTJPostRequest:(NSString *)jsonStr{
    
    //防止在极限情况下(正好够了提交条数)后台和本次提交两次数据
    if (((SouFunAppDelegate*)[UIApplication sharedApplication].delegate).isHouTaiActive) {
        return;
    }
    NSMutableDictionary * requestDic = [[NSMutableDictionary alloc]init];
    [requestDic setObject:@"tongjiPageOptInfo" forKey:@"messagename"];
    NSString * tempUrl = [UtilityHelper getInterfaceAndParamersUrl:INTERFACE_FOR_SPACE paramers:requestDic];
    __weak ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:tempUrl]];
    [request setRequestMethod:@"POST"];
    //[request setPostValue:@"tongjiPageOptInfo" forKey:@"messagename"];
    jsonStr = [jsonStr lowercaseString];
    //NSLog(@"$$$$$$$$$$=====pbjson======$$$$$$$$$ = %@",jsonStr);
    if (jsonStr != nil && jsonStr.length > 0) {
        [request setPostValue:jsonStr forKey:@"ut_loginfo"];
    }
    else{
        return;
    }
    [request clearCacheSetingForRequest];
    //友盟出错修改8.4.0
    if (request==nil||![request isKindOfClass:[ASIFormDataRequest class]]) {
        return;
    }
    
    [request setCompletionBlock:^{
        [self pbRequestCompletDeal:request];
    }];
    [request setFailedBlock:^{
        [self pbRequestCompletDeal:request];
    }];
    
    [request startAsynchronous];
    [self removeAllPBTask];
    
    
}
- (void)pbRequestCompletDeal:(ASIFormDataRequest*)request{
    
    
    NSData * data = request.responseData;
    NSString *jsonStr = [[NSString alloc] initWithData:data encoding:[request responseEncoding]];
    //NSLog(@"PBRespon = %@", jsonStr);
    NSString * repStr = @"{\"result\":\"1\"}";
    if (jsonStr != nil && [jsonStr isEqualToString:repStr]) {
        //NSLog(@"行为日志提交成功");
        //提交成功后清空内存数据，并删除文件
        [self deletePBFile];
        [self removeAllPBTask];
    }
    else{
        //提交失败保存文件，并删除内存数据
        //NSLog(@"行为日志提交失败");
        //获取postJson数据
        NSMutableArray * ary = [request postData];
        NSMutableArray * jsonAry = nil;
        if (ary != nil && ary.count > 0) {
            NSDictionary * dic = [ary objectAtSafeIndex:0];
            NSString * tempJsonStr = [dic objectForKey:@"value"];
            if (tempJsonStr != nil && tempJsonStr.length > 0) {
                jsonAry = [NSJSONSerialization JSONObjectWithData:[tempJsonStr dataUsingEncoding:NSUTF8StringEncoding] options:NSJSONReadingMutableContainers error:nil];
            }
        }
        [self savePBFile:jsonAry];
    }
    
}

-(void)savePBFile:(NSMutableArray*)jsonAry{
    
    if ([self fileSizeAtPath] > 1024*1660) {
        [self deletePBFile];
        [self removeAllPBTask];
        return;
    }
    //NSLog(@"沙盒路径：%@", NSHomeDirectory());
    NSString *filePath = [self completeFilePath];
    if (jsonAry !=nil && jsonAry.count > 0) {
        NSMutableArray * ary = [[NSMutableArray alloc] init];
        [ary addObjectsFromArray:jsonAry];
        [ary writeToFile:filePath atomically:YES];
        [self removeAllPBTask];
    }
    
}
-(NSMutableArray *)ReadPBFile{
    NSString * filePath = [self completeFilePath];
    NSFileManager * manager = [NSFileManager defaultManager];
    if ([manager fileExistsAtPath:filePath]) {
        NSMutableArray * tempAry = [[NSMutableArray alloc] initWithContentsOfFile:filePath];
        return tempAry;
    }
    else{
        NSMutableArray * temp = [[NSMutableArray alloc] init];
        return temp;
    }
    
}
- (void)deletePBFile{
    
    NSFileManager * fileManager = [NSFileManager defaultManager];
    //如果文件存在则删除文件
    NSString * filePath = [self completeFilePath];
    if ([fileManager fileExistsAtPath:filePath]) {
        BOOL res=[fileManager removeItemAtPath:filePath error:nil];
        if (res) {
            //NSLog(@"文件删除成功");
        }else{
            //NSLog(@"文件删除失败");
        }
    }
}
- (long long)fileSizeAtPath{
    
    NSFileManager* manager = [NSFileManager defaultManager];
    if ([manager fileExistsAtPath:[self completeFilePath]]){
        UInt64 * tempInt = [[manager attributesOfItemAtPath:[self completeFilePath] error:nil] fileSize];
        return tempInt;
    }
    return 0;
}

-(NSString*)completeFilePath{
    NSString *localPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    return  [localPath  stringByAppendingPathComponent:STR_PBFileName];
}

- (void)removeAllPBTask{
    if (_pageTaskAry !=nil && _pageTaskAry.count > 0) {
        [_pageTaskAry removeAllObjects];
    }
    if (_eventTaskAry != nil && _eventTaskAry.count > 0) {
        [_eventTaskAry removeAllObjects];
    }
}


@end
