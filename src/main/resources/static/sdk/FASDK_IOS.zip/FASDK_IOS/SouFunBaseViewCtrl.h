//
//  SouFunBaseViewCtrl.h
//  功用：通用控制器基类
//  使用场景：目前在需要做页面停留时间或页面读完统计的地方需要继承
//  创建时间：2017-10-20
//  创建人：于静波
//

#import <UIKit/UIKit.h>

@interface SouFunBaseViewCtrl : UIViewController{
    
    UInt64  _startTime;         //进入页面时间(子类直接用，不需要赋值)
    UInt64  _endTime;           //离开页面时间(子类直接用，不需要赋值)
    NSString * _pageName;       //当前页面名称
    NSString * _pageFrom;       //页面来源
    NSString * _pageF_From;     //页面的来源的来源
    NSString * _pageUrl;        //统计页面停留时间时需要用到
    NSMutableDictionary * _TJPageExtDic;   //用于统计传参的扩展字典(不需要在子类中alloc该字典只用于接收页面统计对应的扩展参数)
    NSMutableArray * _TJPoAry;             //用于做曝光统计(需要自己alloc)
    BOOL _isNeedPVTJ;              //基类是否记录页面统计
    
}

@property(nonatomic, assign)UInt64 startTime;
@property(nonatomic, assign)UInt64 endTime;
@property(nonatomic, strong)NSString * pageName;
@property(nonatomic, strong)NSString * pageFrom;
@property(nonatomic, strong)NSString * pageF_From;
@property(nonatomic, strong)NSString * pageUrl;
@property(nonatomic, strong)NSMutableDictionary * TJPageExtDic;
@property(nonatomic, strong)NSMutableArray * TJPoAry;
@property(nonatomic, assign)BOOL isNeedPVTJ;

@end
