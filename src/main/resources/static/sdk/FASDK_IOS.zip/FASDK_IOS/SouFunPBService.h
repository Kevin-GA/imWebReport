//
//  SouFunPBService.h
//  功用：用户行为统计
//  使用场景：在需要做页面停留时间或页面读完统计的控制器中调用
//  创建时间：2017-10-20
//  创建人：于静波
//

#import <Foundation/Foundation.h>

//进入页面的方式
typedef enum : NSUInteger {
    E_PushInto, //通过push进入页面
    E_PopInto,  //返回(pop)到该页面
} EEntryMode;

//事件类型
typedef enum : NSUInteger{
    E_Click,  //点击事件
    E_Slide,  //滑动事件
    E_POSlide,//滑动曝光事件
    E_ReadEnd, //读完事件
}EEventType;

@interface SouFunPBService : NSObject{
    
    
}



+(SouFunPBService *)sharedPBService;


#pragma mark --- 以下为新的行为统计SDK使用方法 ---

/*
 功能:获取当前时间(距离1970年的毫秒数)
 */
-(UInt64)getCurrTime;

/**
 功能:获得格式化曝光数据（仅线于拼接曝光Item子项使用）;
 格式:esf@123123@北京@别墅...(个数和顺序需要产品来定)
 参数:
 subPoStr:需要曝光的数据字段比如：房源ID
 可变NSString参数：其他需要提交曝光的数据如：物业类型、城市等（具体数据项及顺序需要依照产品确定）
 */
+(NSString*)getFormatTJPoStr:(NSString *)subPoStr,...NS_REQUIRES_NIL_TERMINATION;
/**
 功能:获得格式化曝光Item数据（仅线于拼接曝光Item使用）;
 格式:esf@123123||esf@45678...
 参数:
 poAry:列表中需要曝光的数据,使用基类SouFunBaseViewCtrl中的属性_TJPoAry(ary中的对象应为“esf@123123”这样格式的字符串)
 可变NSString参数：其他需要提交曝光的数据如：物业类型、城市等（具体数据项及顺序需要依照产品确定）
 */
+(NSString*)getFormatPoItemStr:(NSArray*)poAry;

/*
 功能:添加页面统计,类似于谷歌的页面统计，该方法需要在页面离开时调用（viewWillDisappear）
 参数:
 pagName(必传):当前页面名称(依照产品定出的页面名称来传)
 pageFrom(必传):当前页面的上一级页面名称由上级页面传给当前页的（没有就传nil）
 from_From(必传):当前页面名称的上上级页面名称（没有就传nil）
 startTime(必传):进入页面的时间,（直接传父类SouFunBaseCtrl的startTime）
 extDic(必传):页面扩展参数,没有就传nil(包括从前一级或前两级页面传过来的透传参数)
 */
-(void)addPVTJ:(NSString*)pagName pageFrom:(NSString*)pageFrom from_From:(NSString*)from_From startTime:(UInt64)startTime extDic:(NSMutableDictionary*)extDic;


/*
 功能:添加事件统计,在事件产生时调用
 参数:
 eveName:事件名称(由产品确定)
 pageName:当前页面名称
 eveType:枚举事件类型,比如：点击、滑动等
 extDic:事件对应的扩散字典,没有就传nil
 */
-(void)addEventTJ:(NSString*)eveName pageName:(NSString*)pageName eveType:(EEventType)eveType extDic:(NSMutableDictionary*)extDic;
/*
 功能:简单的点击统计，只支持传页面和事件，不支持扩展参数，类似于以前的GA功能
 参数:
 eveName:事件名称(由产品确定)
 pageName:当前页面名称
 */
+(void)FATJ:(NSString*)eveName pageName:(NSString*)pageName;

/*
 功能:启动时处理行为日志
 */
-(void)SFLanuchPBTJ;
/*
 功能:切入后台是处理行为日志
 */
-(void)SFSubExitPBTJ;








@end
