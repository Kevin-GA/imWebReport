//
//  SouFunBaseViewCtrl.h
//  功用：通用控制器基类
//  使用场景：目前在需要做页面停留时间或页面读完统计的地方需要继承
//  创建时间：2017-10-20
//  创建人：于静波
//

#import "SouFunBaseViewCtrl.h"
#import "PZLWNavigationViewController.h"
#import "SouFunPBService.h"

@interface SouFunBaseViewCtrl ()

@end

@implementation SouFunBaseViewCtrl

- (void)viewDidLoad {
    [super viewDidLoad];
    _TJPageExtDic = [[NSMutableDictionary alloc] init];
    _isNeedPVTJ = YES;
    // Do any additional setup after loading the view.
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    //获取页面进入时间
    _startTime = [[NSDate date] timeIntervalSince1970]*1000;
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    //获取页面停留时间
    _endTime = [[NSDate date] timeIntervalSince1970]*1000;
    if (_pageName != nil && _pageName.length > 0 && _isNeedPVTJ) {
        //添加需要曝光的数据
        if (_TJPoAry != nil && _TJPoAry.count > 0) {
            NSString * tempStr = [SouFunPBService getFormatPoItemStr:_TJPoAry];
            [_TJPageExtDic setObject:tempStr forKey:@"item"];
        }
        [[SouFunPBService sharedPBService] addPVTJ:_pageName pageFrom:_pageFrom from_From:_pageF_From startTime:_startTime extDic:_TJPageExtDic];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)presentViewController:(UIViewController *)viewControllerToPresent animated: (BOOL)flag completion:(void (^ __nullable)(void))completion{
    
    SouFunBaseViewCtrl * ctrl = nil;
    if ([viewControllerToPresent isKindOfClass:[PZLWNavigationViewController class]]) {
        UINavigationController * nav = (UINavigationController*)viewControllerToPresent;
        if (nav.viewControllers != nil && nav.viewControllers.count == 1) {
            id tempCtrl = [nav.viewControllers objectAtIndex:0];
            if ([tempCtrl isKindOfClass:[SouFunBaseViewCtrl class]]) {
                ctrl = (SouFunBaseViewCtrl*)tempCtrl;
                if (ctrl.pageFrom == nil) {
                    ctrl.pageFrom = self.pageName;
                }
                if (ctrl.pageF_From == nil) {
                    ctrl.pageF_From = self.pageFrom;
                }
            }
        }
    }
    [super presentViewController:viewControllerToPresent animated:flag completion:completion];
    
}



@end
